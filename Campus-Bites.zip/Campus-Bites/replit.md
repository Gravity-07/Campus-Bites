# College Canteen Queue

College Canteen Queue helps students order food ahead, track pickup timing, and avoid long canteen lines.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/data-app/src/App.tsx` — student ordering, staff queue, login, assistant, and responsive UI.
- `artifacts/api-server/src/routes/canteen.ts` — menu, account entry, orders, queue, and assistant API routes.
- `lib/api-spec/openapi.yaml` — source of truth for the API contract.
- `lib/db/src/schema/canteen.ts` — PostgreSQL tables for users, menu items, and orders.
- `artifacts/data-app/src/index.css` — visual theme, dark mode, responsive layout, and print styles.

## Architecture decisions

- The first release uses a demo account-entry flow rather than a full identity provider so a hackathon team can try the product immediately.
- Menu and order data are stored in the shared PostgreSQL database; the API seeds the menu on first read when the table is empty.
- The student UI uses generated API hooks and refetches after writes; it does not poll more often than the dashboard refresh floor.

## Product

Students can browse menu categories, add food to a cart, place orders, see order numbers and queue positions, and ask a focused canteen assistant about menu availability, order status, and wait times. Staff can view incoming orders and move them from placed to preparing to ready.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
