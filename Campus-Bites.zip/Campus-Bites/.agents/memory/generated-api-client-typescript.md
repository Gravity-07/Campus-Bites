---
name: Generated API client TypeScript
description: TypeScript configuration needed by generated browser API clients in this workspace.
---

Generated API client output may call `Headers.entries()`. The client package's TypeScript `lib` list must include both `dom` and `dom.iterable` or the workspace library typecheck fails.

**Why:** The generated client relies on the iterable Web API surface, which is not included by the plain `dom` library in this TypeScript setup.

**How to apply:** When regenerating OpenAPI client code, keep `dom.iterable` in the client package compiler options before running the workspace typecheck.