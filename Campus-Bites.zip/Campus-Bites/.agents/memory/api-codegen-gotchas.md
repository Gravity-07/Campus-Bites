---
name: API codegen gotchas
description: Contract-first generation behavior that can affect shared Zod exports.
---

The generated Zod API barrel can collide when an operation's path and query parameter schemas share a generated name with an API export. Keep the barrel exports explicit or remove the redundant generated-types star export when TypeScript reports duplicate members.

**Why:** Orval generation succeeded while the shared-library typecheck failed on an ambiguous `RemoveFavoriteParams` export.

**How to apply:** After changing OpenAPI operations, run codegen and then the library typecheck; restore the explicit barrel export if generation reintroduces the collision before touching application callers.