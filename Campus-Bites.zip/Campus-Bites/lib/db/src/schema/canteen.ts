import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, numeric, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const usersTable = pgTable("canteen_users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("student"),
  country: text("country").notNull().default("India"),
  college: text("college").notNull().default("Demo College"),
  campusEmail: text("campus_email").notNull().default(""),
  studentId: text("student_id").notNull().default(""),
  currency: text("currency").notNull().default("INR"),
  currencySymbol: text("currency_symbol").notNull().default("₹"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const menuItemsTable = pgTable("canteen_menu_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  category: text("category").notNull(),
  image: text("image").notNull(),
  available: text("available").notNull().default("true"),
  country: text("country").notNull().default("all"),
  college: text("college").notNull().default("all"),
});

export const ordersTable = pgTable("canteen_orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  items: jsonb("items").notNull(),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("INR"),
  currencySymbol: text("currency_symbol").notNull().default("₹"),
  billSent: text("bill_sent").notNull().default("false"),
  deliveryMethod: text("delivery_method").notNull().default("pickup"),
  paymentMethod: text("payment_method").notNull().default("upi"),
  deliveryRecipientName: text("delivery_recipient_name").notNull().default(""),
  deliveryPhone: text("delivery_phone").notNull().default(""),
  deliveryAddress: text("delivery_address").notNull().default(""),
  deliveryBuilding: text("delivery_building").notNull().default(""),
  deliveryInstructions: text("delivery_instructions").notNull().default(""),
  status: text("status").notNull().default("placed"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const favoritesTable = pgTable("canteen_favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  menuItemId: integer("menu_item_id").notNull().references(() => menuItemsTable.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const offersTable = pgTable("canteen_offers", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  code: text("code").notNull(),
  validUntil: text("valid_until").notNull(),
  audience: text("audience").notNull(),
});

export const settingsTable = pgTable("canteen_settings", {
  id: serial("id").primaryKey(),
  receptionName: text("reception_name").notNull(),
  receptionPhone: text("reception_phone").notNull(),
  receptionEmail: text("reception_email").notNull(),
  address: text("address").notNull(),
  note: text("note").notNull(),
});

export const feedbackTable = pgTable("canteen_feedback", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  rating: integer("rating").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export const insertMenuItemSchema = createInsertSchema(menuItemsTable).omit({ id: true });
export const insertOrderSchema = createInsertSchema(ordersTable).omit({ id: true, createdAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
export type MenuItem = typeof menuItemsTable.$inferSelect;
export type Order = typeof ordersTable.$inferSelect;