import "./CampusBitesQuiet.css";
import { useMemo, useState } from "react";
import { Check, ChefHat, Clock3, Heart, Minus, Plus, RefreshCw, Search, ShoppingBag, Sparkles } from "lucide-react";

type Category = "All" | "Meals" | "Fast food" | "Drinks" | "Juices" | "Cakes" | "Ice cream";
type MenuItem = { id: number; name: string; category: Exclude<Category, "All">; price: number; description: string; glyph: string; tone: string };

const categories: Category[] = ["All", "Meals", "Fast food", "Drinks", "Juices", "Cakes", "Ice cream"];
const menu: MenuItem[] = [
  { id: 1, name: "Paneer thali", category: "Meals", price: 86, description: "Dal, two sabzis, roti and today's rice.", glyph: "◒", tone: "meal" },
  { id: 2, name: "Masala dosa", category: "Fast food", price: 54, description: "Crisp dosa with coconut chutney.", glyph: "◓", tone: "fast" },
  { id: 3, name: "Filter coffee", category: "Drinks", price: 24, description: "Strong, sweet and poured fresh.", glyph: "◉", tone: "drink" },
  { id: 4, name: "Mango lassi", category: "Juices", price: 42, description: "Thick yogurt, ripe mango, cardamom.", glyph: "◌", tone: "juice" },
  { id: 5, name: "Nankhatai", category: "Cakes", price: 31, description: "Crumbly saffron shortbread, two pieces.", glyph: "✦", tone: "cake" },
  { id: 6, name: "Tender coconut", category: "Ice cream", price: 38, description: "A cool scoop with toasted coconut.", glyph: "◔", tone: "ice" },
];

export function CampusBitesQuiet() {
  const [activeNav, setActiveNav] = useState("Order food");
  const [category, setCategory] = useState<Category>("All");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<Record<number, number>>({ 1: 1, 3: 1 });
  const [favorites, setFavorites] = useState<number[]>([2]);
  const [payment, setPayment] = useState("UPI — instant campus payment");
  const [notice, setNotice] = useState("");

  const filteredMenu = useMemo(() => menu.filter((item) => {
    const matchesCategory = category === "All" || item.category === category;
    const matchesSearch = `${item.name} ${item.description}`.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  }), [category, search]);
  const cartItems = menu.filter((item) => cart[item.id]).map((item) => ({ item, quantity: cart[item.id] }));
  const total = cartItems.reduce((sum, entry) => sum + entry.item.price * entry.quantity, 0);
  const cartCount = cartItems.reduce((sum, entry) => sum + entry.quantity, 0);

  const adjustCart = (id: number, delta: number) => {
    setCart((current) => {
      const next = Math.max(0, (current[id] ?? 0) + delta);
      const copy = { ...current };
      if (next) copy[id] = next; else delete copy[id];
      return copy;
    });
  };
  const announce = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2300);
  };

  return (
    <div className="quiet-app">
      <header className="quiet-header">
        <div className="quiet-header-inner">
          <button className="quiet-brand" onClick={() => setActiveNav("Order food")} aria-label="Go to order food">
            <span className="quiet-mark"><ChefHat size={19} strokeWidth={2.3} /></span>
            <span><span className="quiet-brand-name">Campus bites</span><span className="quiet-brand-sub">the quiet counter</span></span>
          </button>
          <nav className="quiet-nav" aria-label="Main navigation">
            {["Order food", "Ask canteen", "Operations"].map((item) => (
              <button key={item} className={activeNav === item ? "active" : ""} onClick={() => { setActiveNav(item); announce(`${item} view selected`); }}>{item}</button>
            ))}
          </nav>
          <div className="quiet-header-actions">
            <button className="quiet-header-action" onClick={() => announce("Print view is ready")} aria-label="Print page"><span className="quiet-mono">⌘P</span></button>
            <div className="quiet-account"><span className="quiet-avatar">SK</span><span>Samira</span></div>
          </div>
        </div>
      </header>

      <main className="quiet-main">
        <div className="quiet-topline">
          <div>
            <div className="quiet-kicker quiet-mono">Canteen / order ahead</div>
            <h1 className="quiet-display quiet-title">A better lunch<br />starts <em style={{ color: "var(--clay)", fontStyle: "normal" }}>here.</em></h1>
            <p className="quiet-description">Browse what is cooking, place your order in under a minute, and arrive when the counter is ready for you.</p>
          </div>
          <div className="quiet-refresh"><span className="quiet-mono">Updated 12:42 PM</span><button onClick={() => announce("Menu refreshed")}><RefreshCw size={13} /> Refresh</button></div>
        </div>

        <div className="quiet-layout">
          <div className="quiet-content">
            <section className="quiet-hero">
              <div className="quiet-hero-copy">
                <div className="quiet-hero-kicker quiet-mono">Tuesday · today at the canteen</div>
                <h2 className="quiet-display">Good food.<br /><em>Better timing.</em></h2>
              </div>
              <div className="quiet-metrics">
                <div><div className="quiet-metric-label quiet-mono">In queue</div><div className="quiet-metric-value">12</div></div>
                <div><div className="quiet-metric-label quiet-mono">Cooking</div><div className="quiet-metric-value">04</div></div>
                <div><div className="quiet-metric-label quiet-mono">Avg wait</div><div className="quiet-metric-value">18m</div></div>
              </div>
            </section>

            <section className="quiet-order">
              <div className="quiet-order-head">
                <div><div className="quiet-label quiet-mono">Your live order</div><div className="quiet-display quiet-order-number">#CB-1048</div></div>
                <span className="quiet-status">● Preparing</span>
              </div>
              <div className="quiet-order-chips"><span className="quiet-chip"><strong>#3</strong> in pickup queue</span><span className="quiet-chip">1 × Paneer thali · 1 × Filter coffee</span><span className="quiet-chip"><strong>₹110.00</strong></span></div>
              <div className="quiet-progress">
                <div className="quiet-progress-step"><span className="quiet-progress-dot done"><Check size={13} /></span><span className="quiet-progress-name">Placed</span><span className="quiet-progress-note">Order received</span></div>
                <span className="quiet-progress-line done" /><div className="quiet-progress-step"><span className="quiet-progress-dot done"><span style={{ width: 6, height: 6, borderRadius: "50%", background: "currentColor" }} /></span><span className="quiet-progress-name">Preparing</span><span className="quiet-progress-note">Kitchen is on it</span></div>
                <span className="quiet-progress-line" /><div className="quiet-progress-step"><span className="quiet-progress-dot">3</span><span className="quiet-progress-name">Ready</span><span className="quiet-progress-note">Come collect</span></div>
              </div>
            </section>

            <section>
              <div className="quiet-menu-head">
                <div><div className="quiet-section-kicker quiet-mono">The counter</div><h2 className="quiet-display quiet-section-title">What are you having?</h2></div>
                <label className="quiet-search"><Search size={14} /><input aria-label="Search menu" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search the menu" /></label>
              </div>
              <div className="quiet-categories">{categories.map((item) => <button key={item} className={category === item ? "active" : ""} onClick={() => setCategory(item)}>{item}</button>)}</div>
              <div className="quiet-menu-grid">
                {filteredMenu.map((item) => (
                  <article key={item.id} className="quiet-menu-card">
                    <div className={`quiet-menu-art ${item.tone}`}><span className="quiet-menu-category">{item.category}</span><span className="quiet-food-glyph">{item.glyph}</span><button className={`quiet-fav ${favorites.includes(item.id) ? "selected" : ""}`} aria-label={`Favorite ${item.name}`} onClick={() => setFavorites((current) => current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id])}><Heart size={13} fill={favorites.includes(item.id) ? "currentColor" : "none"} /></button></div>
                    <div className="quiet-menu-info"><div className="quiet-menu-name-row"><h3 className="quiet-menu-name">{item.name}</h3><span className="quiet-price">₹{item.price}.00</span></div><p className="quiet-menu-desc">{item.description}</p><button className="quiet-add" onClick={() => { adjustCart(item.id, 1); announce(`${item.name} added to tray`); }}><Plus size={12} style={{ verticalAlign: "-2px", marginRight: 4 }} /> Add to order</button></div>
                  </article>
                ))}
              </div>
            </section>
          </div>

          <aside className="quiet-aside">
            <section className="quiet-tray">
              <div className="quiet-tray-head"><div><div className="quiet-section-kicker quiet-mono">Your tray</div><h2 className="quiet-display quiet-tray-title">Ready when<br />you are.</h2></div><span className="quiet-count">{cartCount}</span></div>
              {cartItems.length === 0 ? <div className="quiet-empty"><ShoppingBag size={22} /><p>Your tray is empty</p><span>Tap “Add to order” on anything that looks good.</span></div> : <div className="quiet-cart-items">{cartItems.map(({ item, quantity }) => <div className="quiet-cart-item" key={item.id}><div><div className="quiet-cart-name">{item.name}</div><div className="quiet-cart-price">₹{item.price * quantity}.00</div></div><div className="quiet-stepper"><button onClick={() => adjustCart(item.id, -1)} aria-label={`Decrease ${item.name}`}><Minus size={11} /></button><span>{quantity}</span><button onClick={() => adjustCart(item.id, 1)} aria-label={`Increase ${item.name}`}><Plus size={11} /></button></div></div>)}</div>}
              <div className="quiet-total"><span>Subtotal</span><strong>₹{total.toFixed(2)}</strong></div>
              <div className="quiet-payment"><label htmlFor="quiet-payment">Payment at checkout</label><select id="quiet-payment" value={payment} onChange={(event) => setPayment(event.target.value)}><option>UPI — instant campus payment</option><option>Card</option><option>Pay at counter</option></select></div>
              <button className="quiet-checkout" disabled={!cartCount} onClick={() => { setCart({}); announce("Order sent to the kitchen"); }}>Place order · UPI <span style={{ marginLeft: 5 }}>→</span></button>
            </section>
            <div className="quiet-note"><Clock3 size={16} /><div><strong>Pickup rhythm</strong>We will move your order through the queue and keep the estimate honest.</div></div>
          </aside>
        </div>

        <div className="quiet-extras">
          <section className="quiet-extra quiet-offer"><div className="quiet-label quiet-mono" style={{ color: "var(--sage)" }}>A little extra</div><h3 className="quiet-display">A calmer break<br />between classes.</h3><p>Use the student code at the counter for a complimentary filter coffee with any thali today.</p><span className="quiet-code">BREAK-12 · valid today</span></section>
          <section className="quiet-extra"><div className="quiet-section-kicker quiet-mono">Reception desk</div><h3 className="quiet-display">Need a hand?</h3><p>North campus canteen · Block C<br />+91 80 4122 1940 · hello@campusbites.in</p><button className="quiet-add" style={{ width: "auto", padding: "8px 13px", marginTop: 15 }} onClick={() => announce("Feedback form opened")}>Send feedback <Sparkles size={12} style={{ verticalAlign: "-2px", marginLeft: 4 }} /></button></section>
        </div>
      </main>
      {notice && <div className="quiet-toast">{notice}</div>}
    </div>
  );
}

export default CampusBitesQuiet;