import { Router, type IRouter } from "express";
import { and, desc, eq, ne, or } from "drizzle-orm";
import { db, feedbackTable, favoritesTable, menuItemsTable, offersTable, ordersTable, settingsTable, usersTable } from "@workspace/db";
import {
  AddFavoriteBody,
  AddFavoriteResponse,
  AskAssistantBody,
  AskAssistantResponse,
  CreateFeedbackBody,
  CreateFeedbackResponse,
  CreateMenuItemBody,
  CreateMenuItemResponse,
  CreateOfferBody,
  CreateOfferResponse,
  CreateOrderBody,
  CreateOrderResponse,
  GetCanteenSettingsResponse,
  GetFavoritesQueryParams,
  GetFavoritesResponse,
  GetFeedbackResponse,
  GetMenuQueryParams,
  GetMenuResponse,
  GetOffersResponse,
  GetOrderBillParams,
  GetOrderBillResponse,
  GetOrdersQueryParams,
  GetOrdersResponse,
  GetQueueSummaryResponse,
  LoginBody,
  LoginResponse,
  RemoveFavoriteParams,
  RemoveFavoriteQueryParams,
  SendOrderBillParams,
  SendOrderBillResponse,
  UpdateCanteenSettingsBody,
  UpdateCanteenSettingsResponse,
  UpdateMenuItemBody,
  UpdateMenuItemParams,
  UpdateMenuItemResponse,
  UpdateOrderStatusBody,
  UpdateOrderStatusParams,
  UpdateOrderStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const localeMap: Record<string, { currency: string; symbol: string; rate: number }> = {
  India: { currency: "INR", symbol: "₹", rate: 1 },
  "United States": { currency: "USD", symbol: "$", rate: 0.012 },
  "United Kingdom": { currency: "GBP", symbol: "£", rate: 0.0095 },
  Canada: { currency: "CAD", symbol: "CA$", rate: 0.016 },
  Australia: { currency: "AUD", symbol: "A$", rate: 0.018 },
  "United Arab Emirates": { currency: "AED", symbol: "د.إ", rate: 0.044 },
};

const menuSeed = [
  ["Masala Maggi", "Wok-tossed noodles with vegetables and a little heat.", 55, "Fast food", "India"],
  ["Paneer Wrap", "Grilled paneer, crunchy slaw, and mint chutney.", 90, "Food", "all"],
  ["Veg Thali", "Rice, dal, sabzi, and roti for a filling campus meal.", 120, "Food", "India"],
  ["Samosa Chaat", "Crispy samosa with yogurt, chutney, and sev.", 65, "Fast food", "India"],
  ["Cold Coffee", "Chilled coffee blended smooth for afternoon classes.", 70, "Drinks", "all"],
  ["Fresh Lime Soda", "Bright, fizzy, and refreshing with a sweet or salted finish.", 45, "Juices", "all"],
  ["Chocolate Cake Slice", "Soft chocolate sponge with a rich ganache layer.", 85, "Cakes", "all"],
  ["Mango Lassi", "Creamy mango yogurt drink served cold.", 75, "Drinks", "India"],
  ["Berry Cheesecake", "A creamy cheesecake slice with berry topping.", 110, "Cakes", "United States"],
  ["Vanilla Ice Cream", "Two scoops with your choice of topping.", 60, "Ice cream", "all"],
  ["Chicken Burger", "Toasted bun, crisp lettuce, and house sauce.", 150, "Fast food", "United States"],
  ["Masala Fries", "Crisp fries tossed with campus masala seasoning.", 80, "Fast food", "all"],
] as const;

const imageFor = (category: string) => {
  const images: Record<string, string> = {
    "Fast food": "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
    Food: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    Drinks: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=800&q=80",
    Juices: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80",
    Cakes: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80",
    "Ice cream": "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=800&q=80",
  };
  return images[category] ?? images.Food;
};

const localeFor = (country: string) => localeMap[country] ?? { currency: "EUR", symbol: "€", rate: 0.011 };

async function ensureSeedData(): Promise<void> {
  const menu = await db.select({ id: menuItemsTable.id }).from(menuItemsTable);
  if (menu.length < menuSeed.length) {
    const existing = await db.select({ name: menuItemsTable.name }).from(menuItemsTable);
    const names = new Set(existing.map((item) => item.name));
    const missing = menuSeed
      .filter(([name]) => !names.has(name))
      .map(([name, description, price, category, country]) => ({
        name,
        description,
        price: price.toFixed(2),
        category,
        image: imageFor(category),
        available: "true",
        country,
        college: "all",
      }));
    if (missing.length) await db.insert(menuItemsTable).values(missing);
  }
  const settings = await db.select({ id: settingsTable.id }).from(settingsTable).limit(1);
  if (!settings.length) {
    await db.insert(settingsTable).values({
      receptionName: "Campus Bites reception",
      receptionPhone: "+91 98765 43210",
      receptionEmail: "canteen@campus.edu",
      address: "Main campus food court",
      note: "Call reception for allergy questions, lost items, or order support.",
    });
  }
  const offers = await db.select({ id: offersTable.id }).from(offersTable).limit(1);
  if (!offers.length) {
    await db.insert(offersTable).values({
      title: "Welcome week treat",
      description: "Get a free lime soda with any meal order this week.",
      code: "WELCOME10",
      validUntil: "This Friday",
      audience: "All students",
    });
  }
}

function toMenuItem(item: typeof menuItemsTable.$inferSelect, country: string) {
  const locale = localeFor(country);
  return {
    id: item.id,
    name: item.name,
    description: item.description,
    price: Number((Number(item.price) * locale.rate).toFixed(2)),
    category: item.category as "Snacks" | "Meals" | "Drinks" | "Food" | "Cakes" | "Juices" | "Ice cream" | "Fast food",
    image: item.image,
    available: item.available === "true",
    currency: locale.currency,
    currencySymbol: locale.symbol,
    country: item.country,
    college: item.college,
  };
}

async function toOrder(order: typeof ordersTable.$inferSelect) {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, order.userId));
  const active = await db
    .select({ id: ordersTable.id })
    .from(ordersTable)
    .where(ne(ordersTable.status, "ready"))
    .orderBy(ordersTable.id);
  return {
    id: order.id,
    orderNumber: order.orderNumber,
    userId: order.userId,
    userName: user?.name ?? "Student",
    items: order.items as Array<{ menuItemId: number; name: string; quantity: number; unitPrice: number }>,
    total: Number(order.total),
    status: order.status as "placed" | "preparing" | "ready",
    queuePosition: order.status === "ready" ? 0 : Math.max(1, active.findIndex((row) => row.id === order.id) + 1),
    createdAt: order.createdAt.toISOString(),
    currency: order.currency,
    currencySymbol: order.currencySymbol,
    billSent: order.billSent === "true",
    deliveryMethod: order.deliveryMethod === "door_delivery" ? "door_delivery" : "pickup",
    paymentMethod: order.paymentMethod === "card" ? "card" : order.paymentMethod === "cash" ? "cash" : "upi",
    deliveryRecipientName: order.deliveryRecipientName ?? "",
    deliveryPhone: order.deliveryPhone ?? "",
    deliveryAddress: order.deliveryAddress ?? "",
    deliveryBuilding: order.deliveryBuilding ?? "",
    deliveryInstructions: order.deliveryInstructions ?? "",
  };
}

router.get("/menu", async (req, res): Promise<void> => {
  await ensureSeedData();
  const query = GetMenuQueryParams.safeParse(req.query);
  const country = query.success && query.data.country ? query.data.country : "India";
  const college = query.success && query.data.college ? query.data.college : "all";
  const items = await db
    .select()
    .from(menuItemsTable)
    .where(
      and(
        or(eq(menuItemsTable.country, "all"), eq(menuItemsTable.country, country)),
        or(eq(menuItemsTable.college, "all"), eq(menuItemsTable.college, college)),
      ),
    )
    .orderBy(menuItemsTable.id);
  res.json(GetMenuResponse.parse(items.map((item) => toMenuItem(item, country))));
});

router.post("/menu", async (req, res): Promise<void> => {
  const parsed = CreateMenuItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [created] = await db
    .insert(menuItemsTable)
    .values({
      ...parsed.data,
      price: parsed.data.price.toFixed(2),
      available: parsed.data.available ? "true" : "false",
    })
    .returning();
  res.status(201).json(CreateMenuItemResponse.parse(toMenuItem(created, parsed.data.country === "all" ? "India" : parsed.data.country)));
});

router.patch("/menu/:menuItemId", async (req, res): Promise<void> => {
  const params = UpdateMenuItemParams.safeParse(req.params);
  const body = UpdateMenuItemBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid menu item." });
    return;
  }
  const [updated] = await db
    .update(menuItemsTable)
    .set({
      ...body.data,
      price: body.data.price.toFixed(2),
      available: body.data.available ? "true" : "false",
    })
    .where(eq(menuItemsTable.id, params.data.menuItemId))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Menu item not found." });
    return;
  }
  res.json(UpdateMenuItemResponse.parse(toMenuItem(updated, body.data.country === "all" ? "India" : body.data.country)));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.name.trim() || !parsed.data.email.includes("@") || !parsed.data.campusEmail.includes("@") || !parsed.data.studentId.trim()) {
    res.status(400).json({ error: "Complete the student or staff profile before entering Campus Bites." });
    return;
  }
  const locale = localeFor(parsed.data.country);
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, parsed.data.email.toLowerCase()));
  const values = {
    name: parsed.data.name.trim(),
    email: parsed.data.email.toLowerCase(),
    role: parsed.data.role,
    country: parsed.data.country,
    college: parsed.data.college,
    campusEmail: parsed.data.campusEmail.toLowerCase(),
    studentId: parsed.data.studentId.trim(),
    currency: locale.currency,
    currencySymbol: locale.symbol,
  };
  const user = existing
    ? (await db.update(usersTable).set(values).where(eq(usersTable.id, existing.id)).returning())[0]
    : (await db.insert(usersTable).values(values).returning())[0];
  if (!user) {
    res.status(400).json({ error: "Unable to create account." });
    return;
  }
  res.json(LoginResponse.parse(user));
});

router.post("/auth/logout", (_req, res): void => {
  res.sendStatus(204);
});

router.get("/favorites", async (req, res): Promise<void> => {
  const parsed = GetFavoritesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const rows = await db.select().from(favoritesTable).where(eq(favoritesTable.userId, parsed.data.userId));
  const items = await db.select().from(menuItemsTable);
  const itemIds = new Set(rows.map((row) => row.menuItemId));
  const user = (await db.select().from(usersTable).where(eq(usersTable.id, parsed.data.userId)))[0];
  res.json(GetFavoritesResponse.parse(items.filter((item) => itemIds.has(item.id)).map((item) => toMenuItem(item, user?.country ?? "India"))));
});

router.post("/favorites", async (req, res): Promise<void> => {
  const parsed = AddFavoriteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [existing] = await db.select().from(favoritesTable).where(and(eq(favoritesTable.userId, parsed.data.userId), eq(favoritesTable.menuItemId, parsed.data.menuItemId)));
  if (!existing) await db.insert(favoritesTable).values(parsed.data);
  const item = (await db.select().from(menuItemsTable).where(eq(menuItemsTable.id, parsed.data.menuItemId)))[0];
  const user = (await db.select().from(usersTable).where(eq(usersTable.id, parsed.data.userId)))[0];
  if (!item) {
    res.status(404).json({ error: "Menu item not found." });
    return;
  }
  res.status(201).json(AddFavoriteResponse.parse(toMenuItem(item, user?.country ?? "India")));
});

router.delete("/favorites/:menuItemId", async (req, res): Promise<void> => {
  const params = RemoveFavoriteParams.safeParse(req.params);
  const query = RemoveFavoriteQueryParams.safeParse(req.query);
  if (!params.success || !query.success) {
    res.status(400).json({ error: "Invalid favorite." });
    return;
  }
  await db.delete(favoritesTable).where(and(eq(favoritesTable.userId, query.data.userId), eq(favoritesTable.menuItemId, params.data.menuItemId)));
  res.sendStatus(204);
});

router.get("/orders", async (req, res): Promise<void> => {
  const parsed = GetOrdersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const rows = parsed.data.role === "staff"
    ? await db.select().from(ordersTable).orderBy(desc(ordersTable.id))
    : await db.select().from(ordersTable).where(eq(ordersTable.userId, parsed.data.userId ?? -1)).orderBy(desc(ordersTable.id));
  res.json(GetOrdersResponse.parse(await Promise.all(rows.map(toOrder))));
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.items.length) {
    res.status(400).json({ error: "Add at least one item to the order." });
    return;
  }
  const deliveryMethod = parsed.data.deliveryMethod ?? "pickup";
  const paymentMethod = parsed.data.paymentMethod ?? "upi";
  const deliveryRecipientName = parsed.data.deliveryRecipientName?.trim() ?? "";
  const deliveryPhone = parsed.data.deliveryPhone?.trim() ?? "";
  const deliveryAddress = parsed.data.deliveryAddress?.trim() ?? "";
  const deliveryBuilding = parsed.data.deliveryBuilding?.trim() ?? "";
  const deliveryInstructions = parsed.data.deliveryInstructions?.trim() ?? "";
  if (deliveryMethod === "door_delivery") {
    const phoneIsValid = /^[0-9+()\-\s]{7,20}$/.test(deliveryPhone);
    if (deliveryRecipientName.length < 2 || deliveryRecipientName.length > 120 || !phoneIsValid || deliveryAddress.length < 5 || deliveryAddress.length > 300 || deliveryBuilding.length > 120 || deliveryInstructions.length > 250) {
      res.status(400).json({ error: "Enter a valid recipient name, phone number, and delivery address." });
      return;
    }
  }
  await ensureSeedData();
  const user = (await db.select().from(usersTable).where(eq(usersTable.id, parsed.data.userId)))[0];
  if (!user) {
    res.status(400).json({ error: "Please complete your profile before ordering." });
    return;
  }
  const menu = await db.select().from(menuItemsTable);
  const byId = new Map(menu.map((item) => [item.id, item]));
  const orderItems: Array<{ menuItemId: number; name: string; quantity: number; unitPrice: number }> = [];
  let total = 0;
  const locale = localeFor(user.country);
  for (const selection of parsed.data.items) {
    const item = byId.get(selection.menuItemId);
    if (!item || item.available !== "true" || selection.quantity < 1 || selection.quantity > 10) {
      res.status(400).json({ error: "One selected item is unavailable." });
      return;
    }
    const unitPrice = Number((Number(item.price) * locale.rate).toFixed(2));
    orderItems.push({ menuItemId: item.id, name: item.name, quantity: selection.quantity, unitPrice });
    total += unitPrice * selection.quantity;
  }
  const [created] = await db.insert(ordersTable).values({
    orderNumber: `CB-${String(Date.now()).slice(-5)}`,
    userId: user.id,
    items: orderItems,
    total: total.toFixed(2),
    currency: locale.currency,
    currencySymbol: locale.symbol,
    billSent: "false",
    deliveryMethod,
    paymentMethod,
    deliveryRecipientName,
    deliveryPhone,
    deliveryAddress,
    deliveryBuilding,
    deliveryInstructions,
    status: "placed",
  }).returning();
  res.status(201).json(CreateOrderResponse.parse(await toOrder(created)));
});

router.patch("/orders/:orderId/status", async (req, res): Promise<void> => {
  const params = UpdateOrderStatusParams.safeParse(req.params);
  const body = UpdateOrderStatusBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid order status." });
    return;
  }
  const [updated] = await db.update(ordersTable).set({ status: body.data.status }).where(eq(ordersTable.id, params.data.orderId)).returning();
  if (!updated) {
    res.status(404).json({ error: "Order not found." });
    return;
  }
  res.json(UpdateOrderStatusResponse.parse(await toOrder(updated)));
});

router.get("/orders/:orderId/bill", async (req, res): Promise<void> => {
  const params = GetOrderBillParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid order." });
    return;
  }
  const order = (await db.select().from(ordersTable).where(eq(ordersTable.id, params.data.orderId)))[0];
  if (!order) {
    res.status(404).json({ error: "Order not found." });
    return;
  }
  const user = (await db.select().from(usersTable).where(eq(usersTable.id, order.userId)))[0];
  res.json(GetOrderBillResponse.parse({
    orderNumber: order.orderNumber,
    studentName: user?.name ?? "Student",
    campusEmail: user?.campusEmail ?? "",
    college: user?.college ?? "",
    items: order.items,
    total: Number(order.total),
    currency: order.currency,
    currencySymbol: order.currencySymbol,
     deliveryMethod: order.deliveryMethod === "door_delivery" ? "door_delivery" : "pickup",
     paymentMethod: order.paymentMethod === "card" ? "card" : order.paymentMethod === "cash" ? "cash" : "upi",
     deliveryRecipientName: order.deliveryRecipientName ?? "",
     deliveryPhone: order.deliveryPhone ?? "",
     deliveryAddress: order.deliveryAddress ?? "",
     deliveryBuilding: order.deliveryBuilding ?? "",
     deliveryInstructions: order.deliveryInstructions ?? "",
    createdAt: order.createdAt.toISOString(),
  }));
});

router.post("/orders/:orderId/bill/send", async (req, res): Promise<void> => {
  const params = SendOrderBillParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid order." });
    return;
  }
  const order = (await db.select().from(ordersTable).where(eq(ordersTable.id, params.data.orderId)))[0];
  if (!order) {
    res.status(404).json({ error: "Order not found." });
    return;
  }
  const user = (await db.select().from(usersTable).where(eq(usersTable.id, order.userId)))[0];
  await db.update(ordersTable).set({ billSent: "true" }).where(eq(ordersTable.id, order.id));
  res.json(SendOrderBillResponse.parse({ sent: true, destination: user?.campusEmail ?? "campus email", message: "The bill is ready to send to the campus email on file." }));
});

router.get("/queue/summary", async (_req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable);
  const activeOrders = orders.filter((order) => order.status !== "ready").length;
  res.json(GetQueueSummaryResponse.parse({
    activeOrders,
    preparing: orders.filter((order) => order.status === "preparing").length,
    ready: orders.filter((order) => order.status === "ready").length,
    estimatedMinutes: Math.max(5, activeOrders * 4),
  }));
});

router.post("/assistant/chat", async (req, res): Promise<void> => {
  const parsed = AskAssistantBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Ask a canteen question to continue." });
    return;
  }
  const message = parsed.data.message.toLowerCase();
  const orders = await db.select().from(ordersTable);
  const active = orders.filter((order) => order.status !== "ready").length;
  let answer = "I can help with menu items, offers, your order status, bills, or the pickup queue.";
  if (message.includes("menu") || message.includes("food") || message.includes("available")) {
    const items = await db.select().from(menuItemsTable).where(eq(menuItemsTable.available, "true"));
    answer = `Campus Bites has ${items.length} available items today, including ${items.slice(0, 3).map((item) => item.name).join(", ")}.`;
  } else if (message.includes("offer") || message.includes("discount") || message.includes("event")) {
    const offer = (await db.select().from(offersTable).limit(1))[0];
    answer = offer ? `${offer.title}: ${offer.description} Use code ${offer.code}.` : "There are no active offers right now.";
  } else if (message.includes("queue") || message.includes("wait")) {
    answer = `There are ${active} active orders. The estimated wait is about ${Math.max(5, active * 4)} minutes.`;
  } else if (message.includes("status") && parsed.data.userId) {
    const latest = (await db.select().from(ordersTable).where(eq(ordersTable.userId, parsed.data.userId)).orderBy(desc(ordersTable.id)).limit(1))[0];
    answer = latest ? `Order ${latest.orderNumber} is ${latest.status}.` : "You do not have an order yet.";
  }
  res.json(AskAssistantResponse.parse({ answer, suggestions: ["Show today's menu", "What offers are active?", "How long is the queue?"] }));
});

router.get("/offers", async (_req, res): Promise<void> => {
  await ensureSeedData();
  res.json(GetOffersResponse.parse(await db.select().from(offersTable).orderBy(desc(offersTable.id))));
});

router.post("/offers", async (req, res): Promise<void> => {
  const parsed = CreateOfferBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [offer] = await db.insert(offersTable).values(parsed.data).returning();
  res.status(201).json(CreateOfferResponse.parse(offer));
});

router.get("/settings", async (_req, res): Promise<void> => {
  await ensureSeedData();
  const settings = (await db.select().from(settingsTable).limit(1))[0];
  res.json(GetCanteenSettingsResponse.parse(settings));
});

router.patch("/settings", async (req, res): Promise<void> => {
  const parsed = UpdateCanteenSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const existing = (await db.select().from(settingsTable).limit(1))[0];
  const settings = existing
    ? (await db.update(settingsTable).set(parsed.data).where(eq(settingsTable.id, existing.id)).returning())[0]
    : (await db.insert(settingsTable).values(parsed.data).returning())[0];
  res.json(UpdateCanteenSettingsResponse.parse(settings));
});

router.get("/feedback", async (_req, res): Promise<void> => {
  const rows = await db.select().from(feedbackTable).orderBy(desc(feedbackTable.id));
  const users = await db.select().from(usersTable);
  const names = new Map(users.map((user) => [user.id, user.name]));
  res.json(GetFeedbackResponse.parse(rows.map((row) => ({
    id: row.id,
    userId: row.userId,
    studentName: names.get(row.userId) ?? "Student",
    rating: row.rating,
    message: row.message,
    createdAt: row.createdAt.toISOString(),
  }))));
});

router.post("/feedback", async (req, res): Promise<void> => {
  const parsed = CreateFeedbackBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [feedback] = await db.insert(feedbackTable).values(parsed.data).returning();
  const user = (await db.select().from(usersTable).where(eq(usersTable.id, parsed.data.userId)))[0];
  res.status(201).json(CreateFeedbackResponse.parse({
    id: feedback.id,
    userId: feedback.userId,
    studentName: user?.name ?? "Student",
    rating: feedback.rating,
    message: feedback.message,
    createdAt: feedback.createdAt.toISOString(),
  }));
});

export default router;