import { Router, type IRouter } from "express";
import { desc, eq, ne } from "drizzle-orm";
import { db, menuItemsTable, ordersTable, usersTable } from "@workspace/db";
import {
  AskAssistantBody,
  AskAssistantResponse,
  CreateOrderBody,
  CreateOrderResponse,
  GetMenuResponse,
  GetOrdersQueryParams,
  GetOrdersResponse,
  GetQueueSummaryResponse,
  LoginBody,
  LoginResponse,
  UpdateOrderStatusBody,
  UpdateOrderStatusParams,
  UpdateOrderStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const sampleMenu = [
  {
    name: "Masala Maggi",
    description: "Wok-tossed noodles with vegetables and a little heat.",
    price: "55.00",
    category: "Snacks",
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80",
    available: "true",
  },
  {
    name: "Paneer Wrap",
    description: "Soft roti, grilled paneer, crunchy slaw, and mint chutney.",
    price: "90.00",
    category: "Meals",
    image: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=800&q=80",
    available: "true",
  },
  {
    name: "Veg Thali",
    description: "A filling daily plate with rice, dal, sabzi, and roti.",
    price: "120.00",
    category: "Meals",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    available: "true",
  },
  {
    name: "Samosa Chaat",
    description: "Crispy samosa topped with yogurt, chutney, and sev.",
    price: "65.00",
    category: "Snacks",
    image: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=800&q=80",
    available: "true",
  },
  {
    name: "Cold Coffee",
    description: "Chilled coffee blended smooth for afternoon classes.",
    price: "70.00",
    category: "Drinks",
    image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=800&q=80",
    available: "true",
  },
  {
    name: "Fresh Lime Soda",
    description: "Bright, fizzy, and refreshing with sweet or salted finish.",
    price: "45.00",
    category: "Drinks",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80",
    available: "true",
  },
];

async function ensureMenu(): Promise<void> {
  const existing = await db.select({ id: menuItemsTable.id }).from(menuItemsTable).limit(1);
  if (existing.length === 0) {
    await db.insert(menuItemsTable).values(sampleMenu);
  }
}

function toMenuItem(item: typeof menuItemsTable.$inferSelect) {
  return {
    id: item.id,
    name: item.name,
    description: item.description,
    price: Number(item.price),
    category: item.category as "Snacks" | "Meals" | "Drinks",
    image: item.image,
    available: item.available === "true",
  };
}

async function toOrder(order: typeof ordersTable.$inferSelect) {
  const [user] = await db
    .select({ name: usersTable.name })
    .from(usersTable)
    .where(eq(usersTable.id, order.userId));
  const active = await db
    .select({ id: ordersTable.id })
    .from(ordersTable)
    .where(ne(ordersTable.status, "ready"))
    .orderBy(ordersTable.id);
  const queuePosition =
    order.status === "ready"
      ? 0
      : Math.max(1, active.findIndex((row) => row.id === order.id) + 1);
  return {
    id: order.id,
    orderNumber: order.orderNumber,
    userId: order.userId,
    userName: user?.name ?? "Student",
    items: order.items as Array<{
      menuItemId: number;
      name: string;
      quantity: number;
      unitPrice: number;
    }>,
    total: Number(order.total),
    status: order.status as "placed" | "preparing" | "ready",
    queuePosition,
    createdAt: order.createdAt.toISOString(),
  };
}

router.get("/menu", async (_req, res): Promise<void> => {
  await ensureMenu();
  const items = await db.select().from(menuItemsTable).orderBy(menuItemsTable.id);
  res.json(GetMenuResponse.parse(items.map(toMenuItem)));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.name.trim() || !parsed.data.email.includes("@")) {
    res.status(400).json({ error: "Enter a name, valid email, password, and role." });
    return;
  }

  const [existing] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, parsed.data.email.toLowerCase()));
  const user =
    existing ??
    (
      await db
        .insert(usersTable)
        .values({
          name: parsed.data.name.trim(),
          email: parsed.data.email.toLowerCase(),
          role: parsed.data.role,
        })
        .returning()
    )[0];

  if (!user) {
    res.status(400).json({ error: "Unable to create account." });
    return;
  }
  res.json(LoginResponse.parse({ id: user.id, name: user.name, email: user.email, role: user.role }));
});

router.post("/auth/logout", (_req, res): void => {
  res.sendStatus(204);
});

router.get("/orders", async (req, res): Promise<void> => {
  const parsed = GetOrdersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const rows =
    parsed.data.role === "staff"
      ? await db.select().from(ordersTable).orderBy(desc(ordersTable.id))
      : await db
          .select()
          .from(ordersTable)
          .where(eq(ordersTable.userId, parsed.data.userId ?? -1))
          .orderBy(desc(ordersTable.id));
  const response = await Promise.all(rows.map(toOrder));
  res.json(GetOrdersResponse.parse(response));
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success || parsed.data.items.length === 0) {
    res.status(400).json({ error: "Add at least one available item to your order." });
    return;
  }
  await ensureMenu();
  const menu = await db.select().from(menuItemsTable);
  const menuById = new Map(menu.map((item) => [item.id, item]));
  const orderItems = [];
  let total = 0;
  for (const item of parsed.data.items) {
    const menuItem = menuById.get(item.menuItemId);
    if (!menuItem || menuItem.available !== "true" || item.quantity < 1 || item.quantity > 10) {
      res.status(400).json({ error: "One of the selected items is unavailable." });
      return;
    }
    const unitPrice = Number(menuItem.price);
    orderItems.push({
      menuItemId: menuItem.id,
      name: menuItem.name,
      quantity: item.quantity,
      unitPrice,
    });
    total += unitPrice * item.quantity;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, parsed.data.userId));
  if (!user) {
    res.status(400).json({ error: "Please sign in before placing an order." });
    return;
  }
  const [created] = await db
    .insert(ordersTable)
    .values({
      orderNumber: `CC-${String(Date.now()).slice(-5)}`,
      userId: user.id,
      items: orderItems,
      total: total.toFixed(2),
      status: "placed",
    })
    .returning();
  if (!created) {
    res.status(400).json({ error: "Unable to place order." });
    return;
  }
  res.status(201).json(CreateOrderResponse.parse(await toOrder(created)));
});

router.patch("/orders/:orderId/status", async (req, res): Promise<void> => {
  const params = UpdateOrderStatusParams.safeParse(req.params);
  const body = UpdateOrderStatusBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid order status." });
    return;
  }
  const [updated] = await db
    .update(ordersTable)
    .set({ status: body.data.status })
    .where(eq(ordersTable.id, params.data.orderId))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Order not found." });
    return;
  }
  res.json(UpdateOrderStatusResponse.parse(await toOrder(updated)));
});

router.get("/queue/summary", async (_req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable);
  const activeOrders = orders.filter((order) => order.status !== "ready").length;
  const preparing = orders.filter((order) => order.status === "preparing").length;
  const ready = orders.filter((order) => order.status === "ready").length;
  res.json(
    GetQueueSummaryResponse.parse({
      activeOrders,
      preparing,
      ready,
      estimatedMinutes: Math.max(5, activeOrders * 4),
    }),
  );
});

router.post("/assistant/chat", async (req, res): Promise<void> => {
  const parsed = AskAssistantBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Ask a canteen question to continue." });
    return;
  }
  const message = parsed.data.message.toLowerCase();
  const [summary] = await Promise.all([
    (async () => {
      const orders = await db.select().from(ordersTable);
      const active = orders.filter((order) => order.status !== "ready").length;
      return { active, wait: Math.max(5, active * 4) };
    })(),
  ]);
  let answer =
    "I can help with today's menu, your order status, or the current queue. Try asking one of those.";
  if (message.includes("menu") || message.includes("food") || message.includes("available")) {
    await ensureMenu();
    const menu = await db.select().from(menuItemsTable).where(eq(menuItemsTable.available, "true"));
    answer = `Today's menu has ${menu.length} available items, including ${menu
      .slice(0, 3)
      .map((item) => item.name)
      .join(", ")}.`;
  } else if (message.includes("queue") || message.includes("long") || message.includes("wait")) {
    answer = `There are ${summary.active} active orders right now. The estimated wait is about ${summary.wait} minutes.`;
  } else if (message.includes("status") && parsed.data.userId) {
    const [latest] = await db
      .select()
      .from(ordersTable)
      .where(eq(ordersTable.userId, parsed.data.userId))
      .orderBy(desc(ordersTable.id))
      .limit(1);
    answer = latest
      ? `Order ${latest.orderNumber} is ${latest.status === "placed" ? "placed and waiting to be prepared" : latest.status}.`
      : "You do not have an order yet. Add a meal from the menu to get started.";
  }
  res.json(
    AskAssistantResponse.parse({
      answer,
      suggestions: ["What food is available?", "What is my order status?", "How long is the queue?"],
    }),
  );
});

export default router;