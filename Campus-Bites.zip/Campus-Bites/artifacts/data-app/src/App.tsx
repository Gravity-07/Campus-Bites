import { type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import NotFound from '@/pages/not-found';
import {
  getGetMenuQueryKey,
  getGetFavoritesQueryKey,
  getGetOrderBillQueryKey,
  getGetOrdersQueryKey,
  getGetQueueSummaryQueryKey,
  useAskAssistant,
  useAddFavorite,
  useCreateOrder,
  useCreateFeedback,
  useGetCanteenSettings,
  useGetFeedback,
  useGetFavorites,
  useGetMenu,
  useGetOffers,
  useGetOrders,
  useGetQueueSummary,
  useLogin,
  useLogout,
  useGetOrderBill,
  useSendOrderBill,
  useUpdateMenuItem,
  useUpdateOrderStatus,
  useRemoveFavorite,
  type MenuItem,
  type Order,
  type User,
} from '@workspace/api-client-react';
import {
  ArrowRight,
  Bot,
  Check,
  ChefHat,
  ChevronDown,
  Clock3,
  Heart,
  Download,
  DoorOpen,
  LayoutDashboard,
  LogIn,
  LogOut,
  Mail,
  MapPin,
  Phone,
  Minus,
  Moon,
  PackageCheck,
  Plus,
  Printer,
  RefreshCw,
  Search,
  Send,
  ShoppingBag,
  Sparkles,
  Star,
  Sun,
  UtensilsCrossed,
  Users,
  X,
} from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 5 * 60 * 1000, refetchOnWindowFocus: false },
  },
});

type Role = 'student' | 'staff';
type DeliveryMethod = 'pickup' | 'door_delivery';
type PaymentMethod = 'upi' | 'card' | 'cash';
type Category = 'All' | 'Snacks' | 'Meals' | 'Drinks' | 'Food' | 'Cakes' | 'Juices' | 'Ice cream' | 'Fast food';

const menuCategories: Category[] = ['All', 'Food', 'Fast food', 'Drinks', 'Juices', 'Cakes', 'Ice cream'];
const statusLabels = { placed: 'Placed', preparing: 'Preparing', ready: 'Ready' } as const;

function readUser(): User | null {
  try {
    const value = localStorage.getItem('canteen-user');
    return value ? (JSON.parse(value) as User) : null;
  } catch {
    return null;
  }
}

function useCurrentUser() {
  const [user, setUser] = useState<User | null>(() => readUser());
  useEffect(() => {
    const syncUser = () => setUser(readUser());
    window.addEventListener('canteen-user-change', syncUser);
    return () => window.removeEventListener('canteen-user-change', syncUser);
  }, []);
  const saveUser = (next: User | null) => {
    setUser(next);
    if (next) localStorage.setItem('canteen-user', JSON.stringify(next));
    else localStorage.removeItem('canteen-user');
    window.dispatchEvent(new Event('canteen-user-change'));
  };
  return { user, saveUser };
}

function useDarkMode() {
  const [isDark, setIsDark] = useState(() => localStorage.getItem('canteen-theme') === 'dark');
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
    localStorage.setItem('canteen-theme', isDark ? 'dark' : 'light');
  }, [isDark]);
  return { isDark, setIsDark };
}

function IconButton({ label, onClick, children, disabled = false }: { label: string; onClick: () => void; children: ReactNode; disabled?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      data-testid={`button-${label.toLowerCase().replaceAll(' ', '-')}`}
      onClick={onClick}
      disabled={disabled}
      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"
    >
      {children}
    </button>
  );
}

function StatusBadge({ status }: { status: keyof typeof statusLabels }) {
  const styles = {
    placed: 'bg-[hsl(var(--secondary)/.55)] text-[hsl(var(--foreground))]',
    preparing: 'bg-[hsl(var(--primary)/.15)] text-[hsl(var(--primary))]',
    ready: 'bg-[hsl(var(--accent)/.14)] text-[hsl(var(--accent))]',
  };
  return (
    <span data-testid={`status-order-${status}`} className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold ${styles[status]}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {statusLabels[status]}
    </span>
  );
}

function LogoMark() {
  return (
    <span className="relative inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-[14px] bg-primary text-primary-foreground shadow-sm">
      <ChefHat className="h-5 w-5" strokeWidth={2.5} />
      <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full border-2 border-background bg-[hsl(var(--secondary))]" />
    </span>
  );
}

function HeaderActions() {
  const { isDark, setIsDark } = useDarkMode();
  return (
    <div className="flex items-center gap-2 print-hidden">
      <IconButton label="print page" onClick={() => window.print()}>
        <Printer className="h-4 w-4" />
      </IconButton>
      <IconButton label="toggle dark mode" onClick={() => setIsDark((value) => !value)}>
        {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </IconButton>
    </div>
  );
}

function Shell({ children, user, onLogout }: { children: ReactNode; user: User | null; onLogout: () => void }) {
  const [location] = useLocation();
  const links = [
    { href: '/', label: 'Order food', icon: ShoppingBag },
    { href: '/assistant', label: 'Ask canteen', icon: Bot },
    ...(user?.role === 'staff' ? [{ href: '/staff', label: 'Operations', icon: LayoutDashboard }] : []),
  ];
  return (
    <div className="min-h-[100dvh] bg-background">
      <header className="sticky top-0 z-40 isolate border-b border-border/80 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1480px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          <Link href="/" className="group flex items-center gap-3" data-testid="link-brand">
            <LogoMark />
            <span className="hidden sm:block">
              <span className="block font-display text-[21px] leading-none tracking-tight">Campus <span className="text-primary">bites</span></span>
              <span className="mt-1 block font-mono-app text-[9px] uppercase tracking-[.2em] text-muted-foreground">campus canteen</span>
            </span>
          </Link>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
            {links.map((link) => {
              const active = location === link.href;
              const Icon = link.icon;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  data-testid={`link-nav-${link.label.toLowerCase().replaceAll(' ', '-')}`}
                  className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition-colors ${active ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}
                >
                  <Icon className="h-4 w-4" />
                  {link.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center gap-2">
            <HeaderActions />
            {user ? (
              <div className="group relative hidden sm:block">
                <button type="button" data-testid="button-account-menu" className="flex items-center gap-2 rounded-xl border border-border bg-card px-2.5 py-1.5 text-left">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[hsl(var(--secondary))] text-xs font-extrabold">{user.name.slice(0, 1).toUpperCase()}</span>
                  <span className="max-w-[110px] truncate text-sm font-bold">{user.name}</span>
                  <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                </button>
                <div className="invisible absolute right-0 top-full mt-2 w-48 translate-y-1 rounded-2xl border border-border bg-card p-2 opacity-0 shadow-lg transition-all group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                  <div className="border-b border-border px-3 py-2">
                    <p className="truncate text-sm font-bold">{user.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                  </div>
                  <button type="button" onClick={onLogout} data-testid="button-log-out" className="mt-1 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-muted-foreground hover:bg-muted hover:text-foreground">
                    <LogOut className="h-4 w-4" /> Sign out
                  </button>
                </div>
              </div>
            ) : (
              <Link href="/login" data-testid="link-sign-in" className="inline-flex items-center gap-2 rounded-xl bg-foreground px-3.5 py-2 text-sm font-bold text-background transition-transform hover:-translate-y-0.5">
                <LogIn className="h-4 w-4" /> <span className="hidden sm:inline">Sign in</span>
              </Link>
            )}
          </div>
        </div>
      </header>
      <main>{children}</main>
      <nav className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-3 border-t border-border bg-card/95 p-2 backdrop-blur-xl md:hidden print-hidden">
        {links.map((link) => {
          const active = location === link.href;
          const Icon = link.icon;
          return (
            <Link key={link.href} href={link.href} data-testid={`link-mobile-${link.label.toLowerCase().replaceAll(' ', '-')}`} className={`flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] font-bold ${active ? 'bg-[hsl(var(--primary)/.12)] text-primary' : 'text-muted-foreground'}`}>
              <Icon className="h-4 w-4" /> {link.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

function RefreshControls({ onRefresh, isFetching, updatedAt, withAuto = true }: { onRefresh: () => void; isFetching: boolean; updatedAt?: number; withAuto?: boolean }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [intervalMs, setIntervalMs] = useState(5 * 60 * 1000);
  const rootRef = useRef<HTMLDivElement>(null);
  const refreshRef = useRef(onRefresh);
  refreshRef.current = onRefresh;
  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);
  useEffect(() => {
    if (!autoRefresh || !withAuto) return;
    const timer = window.setInterval(() => refreshRef.current(), intervalMs);
    return () => window.clearInterval(timer);
  }, [autoRefresh, intervalMs, withAuto]);
  const refreshedLabel = updatedAt ? `${new Date(updatedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}` : 'Not refreshed yet';
  return (
    <div ref={rootRef} className="relative z-50 flex items-center gap-2">
      <div className="flex h-9 overflow-hidden rounded-xl border border-border bg-card">
        <button type="button" disabled={isFetching} onClick={onRefresh} data-testid="button-refresh-data" className="flex items-center gap-2 px-3 text-xs font-bold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-50">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
        </button>
        {withAuto && (
          <>
            <span className="my-2 w-px bg-border" />
            <button type="button" onClick={() => setMenuOpen((value) => !value)} data-testid="button-refresh-options" className="px-2 text-muted-foreground hover:bg-muted">
              <ChevronDown className="h-3.5 w-3.5" />
            </button>
          </>
        )}
      </div>
      <span className="hidden font-mono-app text-[10px] text-muted-foreground lg:inline">Updated {refreshedLabel}</span>
      {menuOpen && (
        <div className="absolute right-0 top-11 z-40 w-56 rounded-2xl border border-border bg-card p-3 shadow-xl">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div><p className="text-xs font-bold">Auto-refresh</p><p className="text-[10px] text-muted-foreground">Off by default</p></div>
            <button type="button" role="switch" aria-checked={autoRefresh} onClick={() => setAutoRefresh((value) => !value)} data-testid="switch-auto-refresh" className={`relative h-5 w-9 rounded-full transition-colors ${autoRefresh ? 'bg-primary' : 'bg-muted'}`}>
              <span className={`absolute top-1 h-3 w-3 rounded-full bg-card transition-transform ${autoRefresh ? 'translate-x-5' : 'translate-x-1'}`} />
            </button>
          </div>
          <p className="mb-2 mt-3 text-[10px] font-bold uppercase tracking-[.12em] text-muted-foreground">Interval</p>
          {[{ label: 'Every 5 minutes', value: 5 * 60 * 1000 }, { label: 'Every 15 minutes', value: 15 * 60 * 1000 }, { label: 'Every hour', value: 60 * 60 * 1000 }].map((option) => (
            <button type="button" key={option.value} onClick={() => setIntervalMs(option.value)} data-testid={`button-interval-${option.value}`} className="flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-left text-xs hover:bg-muted">
              {option.label}{intervalMs === option.value && <Check className="h-3.5 w-3.5 text-primary" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function PageFrame({ eyebrow, title, description, actions, children }: { eyebrow: string; title: string; description: string; actions?: ReactNode; children: ReactNode }) {
  return (
    <div className="surface-grid min-h-[calc(100dvh-72px)] px-4 pb-28 pt-8 sm:px-6 lg:px-8 lg:pb-12">
      <div className="mx-auto max-w-[1480px]">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-5">
          <div className="fade-up">
            <p className="mb-2 font-mono-app text-[10px] font-bold uppercase tracking-[.22em] text-primary">{eyebrow}</p>
            <h1 className="text-balance font-display text-4xl leading-[.98] tracking-tight sm:text-5xl">{title}</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground">{description}</p>
          </div>
          {actions && <div className="fade-up-delay-1 fade-up">{actions}</div>}
        </div>
        {children}
      </div>
    </div>
  );
}

function LoadingRows({ count = 3 }: { count?: number }) {
  return <div className="space-y-3">{Array.from({ length: count }).map((_, index) => <div key={index} className="h-16 animate-pulse rounded-2xl bg-muted" />)}</div>;
}

function ErrorNotice({ message = 'We could not load this view.' }: { message?: string }) {
  return <div data-testid="state-error" className="rounded-2xl border border-[hsl(var(--destructive)/.25)] bg-[hsl(var(--destructive)/.08)] p-5 text-sm text-[hsl(var(--destructive))]"><p className="font-bold">Something went off the tray.</p><p className="mt-1 opacity-90">{message} Try refreshing.</p></div>;
}

function EmptyState({ title, description, icon: Icon = ShoppingBag }: { title: string; description: string; icon?: typeof ShoppingBag }) {
  return <div data-testid="state-empty" className="flex min-h-48 flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card/60 px-6 text-center"><span className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-muted text-primary"><Icon className="h-5 w-5" /></span><h3 className="font-display text-xl">{title}</h3><p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p></div>;
}

function MenuVisual({ item }: { item: MenuItem }) {
  return (
    <div className="relative h-36 overflow-hidden rounded-2xl bg-[hsl(var(--muted))]">
      <div className="absolute inset-0 opacity-70" style={{ background: item.category === 'Meals' ? 'linear-gradient(140deg, #f9bf59, #e66b45)' : item.category === 'Drinks' ? 'linear-gradient(140deg, #78c9c0, #137c8b)' : 'linear-gradient(140deg, #d9e78b, #ed8c57)' }} />
      {item.image ? <img src={item.image} alt={item.name} className="relative h-full w-full object-cover mix-blend-multiply" loading="lazy" /> : <UtensilsCrossed className="absolute left-1/2 top-1/2 h-10 w-10 -translate-x-1/2 -translate-y-1/2 text-white/80" />}
      <span className="absolute left-3 top-3 rounded-full bg-background/85 px-2 py-1 font-mono-app text-[9px] font-bold uppercase tracking-wider">{item.category}</span>
    </div>
  );
}

function OrderProgress({ order }: { order: Order }) {
  const steps: Array<{ key: Order['status']; label: string; note: string }> = [
    { key: 'placed', label: 'Placed', note: 'Order received' },
    { key: 'preparing', label: 'Preparing', note: 'Kitchen is on it' },
    { key: 'ready', label: 'Ready', note: order.deliveryMethod === 'door_delivery' ? 'Handed to delivery' : 'Come collect' },
  ];
  const activeIndex = steps.findIndex((step) => step.key === order.status);
  return (
    <div className="mt-6">
      <div className="flex items-start">
        {steps.map((step, index) => (
          <div key={step.key} className="flex flex-1 items-start">
            <div className="flex flex-col items-center">
              <span className={`flex h-8 w-8 items-center justify-center rounded-full border-2 ${index <= activeIndex ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-muted-foreground'}`}>{index < activeIndex ? <Check className="h-4 w-4" /> : <span className="font-mono-app text-xs">{index + 1}</span>}</span>
              <span className={`mt-2 text-xs font-bold ${index <= activeIndex ? 'text-foreground' : 'text-muted-foreground'}`}>{step.label}</span>
              <span className="mt-1 hidden text-center text-[10px] text-muted-foreground sm:block">{step.note}</span>
            </div>
            {index < steps.length - 1 && <span className={`mt-4 h-0.5 flex-1 ${index < activeIndex ? 'bg-primary' : 'bg-border'}`} />}
          </div>
        ))}
      </div>
    </div>
  );
}

function FulfillmentBadge({ order }: { order: Order }) {
  const isDelivery = order.deliveryMethod === 'door_delivery';
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${isDelivery ? 'bg-[hsl(var(--primary)/.12)] text-primary' : 'bg-muted text-muted-foreground'}`}>
      {isDelivery ? <DoorOpen className="h-3.5 w-3.5" /> : <PackageCheck className="h-3.5 w-3.5" />}
      {isDelivery ? 'Door delivery' : 'Pickup'}
    </span>
  );
}

function OrderDetails({ order }: { order: Order }) {
  const isDelivery = order.deliveryMethod === 'door_delivery';
  return (
    <div className="mt-4 grid gap-3 rounded-2xl bg-muted/70 p-4 text-xs sm:grid-cols-2">
      <div>
        <p className="font-mono-app text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Fulfillment</p>
        <div className="mt-2 flex flex-wrap items-center gap-2"><FulfillmentBadge order={order} /><span className="rounded-full bg-card px-2.5 py-1 font-bold">{order.paymentMethod.toUpperCase()}</span></div>
      </div>
      {isDelivery ? (
        <div>
          <p className="font-mono-app text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Delivery details</p>
          <p className="mt-2 break-words font-bold">{order.deliveryRecipientName} · {order.deliveryPhone}</p>
          <p className="mt-1 break-words leading-5 text-muted-foreground">{order.deliveryAddress}{order.deliveryBuilding ? ` · ${order.deliveryBuilding}` : ''}</p>
          {order.deliveryInstructions && <p className="mt-1 break-words leading-5 text-muted-foreground">Note: {order.deliveryInstructions}</p>}
        </div>
      ) : (
        <div>
          <p className="font-mono-app text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Pickup details</p>
          <p className="mt-2 leading-5 text-muted-foreground">Collect from the campus canteen counter when the order is ready.</p>
        </div>
      )}
    </div>
  );
}

function BillActions({ order }: { order: Order }) {
  const billQuery = useGetOrderBill(order.id, { query: { enabled: false, queryKey: getGetOrderBillQueryKey(order.id) } });
  const sendBill = useSendOrderBill();
  const downloadBill = async () => {
    const bill = await billQuery.refetch();
    if (!bill.data) return;
    const fulfillment = bill.data.deliveryMethod === 'door_delivery'
      ? `Door delivery: ${bill.data.deliveryRecipientName}, ${bill.data.deliveryPhone}, ${bill.data.deliveryAddress}${bill.data.deliveryBuilding ? `, ${bill.data.deliveryBuilding}` : ''}`
      : 'Pickup from campus canteen counter';
    const content = [`Campus bites bill`, `Order ${bill.data.orderNumber}`, bill.data.studentName, fulfillment, `Payment: ${bill.data.paymentMethod.toUpperCase()}`, '', ...bill.data.items.map((item) => `${item.quantity} × ${item.name}  ${bill.data?.currencySymbol}${(item.unitPrice * item.quantity).toFixed(2)}`), '', `Total: ${bill.data.currencySymbol}${bill.data.total.toFixed(2)}`].join('\n');
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${bill.data.orderNumber}-bill.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
  };
  return <div className="flex flex-wrap gap-2"><button type="button" onClick={() => void downloadBill()} className="rounded-xl border border-border px-3 py-2 text-xs font-bold hover:bg-muted">Download bill</button><button type="button" onClick={() => sendBill.mutate({ orderId: order.id })} disabled={sendBill.isPending || order.billSent} className="rounded-xl bg-foreground px-3 py-2 text-xs font-bold text-background disabled:opacity-50">{order.billSent ? 'Bill sent' : sendBill.isPending ? 'Sending…' : 'Send to campus email'}</button></div>;
}

function OrderHistoryCard({ order }: { order: Order }) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  return (
    <article className="py-4">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-mono-app text-sm font-bold text-primary">#{order.orderNumber}</p>
            <FulfillmentBadge order={order} />
            <StatusBadge status={order.status} />
          </div>
          <p className="mt-1 break-words text-xs text-muted-foreground">{order.items.map((item) => `${item.quantity} × ${item.name}`).join(' · ')}</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <span className="font-mono-app text-sm font-bold">{order.currencySymbol}{order.total.toFixed(2)}</span>
          <button type="button" onClick={() => setDetailsOpen((value) => !value)} data-testid={`button-order-details-${order.id}`} className="rounded-xl border border-border px-3 py-2 text-xs font-bold hover:bg-muted">{detailsOpen ? 'Hide details' : 'Order details'}</button>
          <BillActions order={order} />
        </div>
      </div>
      {detailsOpen && <OrderDetails order={order} />}
    </article>
  );
}

function CampusExtras({ user, orders }: { user: User; orders: Order[] }) {
  const offersQuery = useGetOffers();
  const settingsQuery = useGetCanteenSettings();
  const feedbackQuery = useGetFeedback();
  const createFeedback = useCreateFeedback();
  const [rating, setRating] = useState(5);
  const [message, setMessage] = useState('');
  const submitFeedback = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!message.trim()) return;
    createFeedback.mutate({ data: { userId: user.id, rating, message: message.trim() } }, { onSuccess: () => { setMessage(''); void feedbackQuery.refetch(); } });
  };
  return <section className="mt-6 grid gap-5 lg:grid-cols-[1fr_1fr]">
    <div className="rounded-3xl border border-border bg-card p-5 sm:p-6">
      <div className="flex items-center justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-primary">Special occasions</p><h2 className="mt-1 font-display text-2xl">Offers for your campus</h2></div><Sparkles className="h-5 w-5 text-primary" /></div>
      <div className="mt-4 space-y-3">{offersQuery.data?.map((offer) => <div key={offer.id} className="rounded-2xl bg-[hsl(var(--secondary)/.2)] p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-bold">{offer.title}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{offer.description}</p></div><span className="rounded-lg bg-card px-2 py-1 font-mono-app text-[10px] font-bold">{offer.code}</span></div><p className="mt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Valid until {offer.validUntil} · {offer.audience}</p></div>) ?? <p className="text-sm text-muted-foreground">No offers right now.</p>}</div>
    </div>
    <div className="rounded-3xl border border-border bg-card p-5 sm:p-6">
      <div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-primary">Reception desk</p><h2 className="mt-1 font-display text-2xl">{settingsQuery.data?.receptionName ?? 'Canteen reception'}</h2></div>
      <div className="mt-4 space-y-3 text-sm text-muted-foreground"><p className="flex gap-2"><Phone className="h-4 w-4 shrink-0 text-primary" /> {settingsQuery.data?.receptionPhone ?? 'Loading phone…'}</p><p className="flex gap-2"><Mail className="h-4 w-4 shrink-0 text-primary" /> {settingsQuery.data?.receptionEmail ?? 'Loading email…'}</p><p className="flex gap-2"><MapPin className="h-4 w-4 shrink-0 text-primary" /> {settingsQuery.data?.address ?? 'Loading address…'}</p><p className="rounded-xl bg-muted p-3 text-xs leading-5">{settingsQuery.data?.note}</p></div>
    </div>
    <div className="rounded-3xl border border-border bg-card p-5 sm:p-6 lg:col-span-2">
      <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-primary">Your history</p><h2 className="mt-1 font-display text-2xl">Previous orders and bills</h2></div><span className="rounded-full bg-muted px-3 py-1 font-mono-app text-[10px] font-bold">{orders.length} orders</span></div>
      <div className="mt-4 divide-y divide-border">{orders.length ? orders.map((order) => <OrderHistoryCard key={order.id} order={order} />) : <p className="py-5 text-sm text-muted-foreground">Your completed orders will appear here.</p>}</div>
    </div>
    <div className="rounded-3xl border border-border bg-card p-5 sm:p-6 lg:col-span-2">
      <div className="flex items-center gap-2"><Star className="h-5 w-5 fill-current text-primary" /><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-primary">Feedback</p><h2 className="mt-1 font-display text-2xl">Help the canteen improve</h2></div></div>
      <form onSubmit={submitFeedback} className="mt-4 grid gap-3 sm:grid-cols-[160px_1fr_auto]"><select value={rating} onChange={(event) => setRating(Number(event.target.value))} className="h-11 rounded-xl border border-border bg-background px-3 text-sm"><option value="5">5 — Great</option><option value="4">4 — Good</option><option value="3">3 — Okay</option><option value="2">2 — Needs work</option><option value="1">1 — Poor</option></select><input value={message} onChange={(event) => setMessage(event.target.value)} placeholder="How was your meal or pickup?" className="h-11 rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" /><button type="submit" disabled={createFeedback.isPending || !message.trim()} className="h-11 rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground disabled:opacity-50">{createFeedback.isPending ? 'Saving…' : 'Send feedback'}</button></form>
      {!!feedbackQuery.data?.length && <p className="mt-3 text-xs text-muted-foreground">{feedbackQuery.data.length} student responses are helping the team improve service.</p>}
    </div>
  </section>;
}

function Home() {
  const { user, saveUser } = useCurrentUser();
  const menuParams = user ? { country: user.country, college: user.college } : { country: 'India', college: 'all' };
  const menuQuery = useGetMenu(menuParams);
  const queueQuery = useGetQueueSummary();
  const userId = user?.id;
  const ordersQuery = useGetOrders(userId ? { userId } : undefined, { query: { enabled: Boolean(userId), queryKey: getGetOrdersQueryKey(userId ? { userId } : undefined) } });
  const favoritesQuery = useGetFavorites({ userId: userId ?? -1 }, { query: { enabled: Boolean(userId), queryKey: getGetFavoritesQueryKey({ userId: userId ?? -1 }) } });
  const queryClient = useQueryClient();
  const createOrder = useCreateOrder();
  const addFavorite = useAddFavorite();
  const removeFavorite = useRemoveFavorite();
  const [category, setCategory] = useState<Category>('All');
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<Record<number, number>>({});
  const [latestOrder, setLatestOrder] = useState<Order | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>('pickup');
  const [deliveryForm, setDeliveryForm] = useState({ recipientName: '', phone: '', address: '', building: '', instructions: '' });
  const menu = menuQuery.data ?? [];
  const favoriteIds = useMemo(() => new Set((favoritesQuery.data ?? []).map((item) => item.id)), [favoritesQuery.data]);
  const filteredMenu = useMemo(() => menu.filter((item) => item.available && (category === 'All' || item.category === category) && `${item.name} ${item.description}`.toLowerCase().includes(search.toLowerCase())), [menu, category, search]);
  const cartItems = useMemo(() => menu.filter((item) => cart[item.id]).map((item) => ({ item, quantity: cart[item.id] })), [menu, cart]);
  const cartTotal = cartItems.reduce((sum, entry) => sum + entry.item.price * entry.quantity, 0);
  const currentOrder = latestOrder ?? ordersQuery.data?.find((order) => order.status !== 'ready');
  const deliveryPhoneIsValid = /^[0-9+()\-\s]{7,20}$/.test(deliveryForm.phone.trim());
  const userName = user?.name.trim() ?? '';
  const deliveryIsValid = deliveryMethod === 'pickup' || (
    (deliveryForm.recipientName.trim() || userName).length >= 2
    && deliveryPhoneIsValid
    && deliveryForm.address.trim().length >= 5
    && deliveryForm.address.trim().length <= 300
    && deliveryForm.building.trim().length <= 120
    && deliveryForm.instructions.trim().length <= 250
  );
  const refresh = () => {
    void Promise.all([menuQuery.refetch(), queueQuery.refetch(), ordersQuery.refetch()]);
  };
  const addToCart = (item: MenuItem) => setCart((value) => ({ ...value, [item.id]: (value[item.id] ?? 0) + 1 }));
  const adjustCart = (id: number, delta: number) => setCart((value) => {
    const next = Math.max(0, (value[id] ?? 0) + delta);
    const copy = { ...value };
    if (next) copy[id] = next; else delete copy[id];
    return copy;
  });
  const placeOrder = () => {
    if (!userId || !cartItems.length || !deliveryIsValid) return;
    const delivery = deliveryMethod === 'door_delivery'
      ? {
          deliveryMethod,
          deliveryRecipientName: deliveryForm.recipientName.trim() || user.name.trim(),
          deliveryPhone: deliveryForm.phone.trim(),
          deliveryAddress: deliveryForm.address.trim(),
          deliveryBuilding: deliveryForm.building.trim(),
          deliveryInstructions: deliveryForm.instructions.trim(),
        }
      : { deliveryMethod };
    createOrder.mutate({ data: { userId, items: cartItems.map(({ item, quantity }) => ({ menuItemId: item.id, quantity })), paymentMethod, ...delivery } }, {
      onSuccess: (order) => {
        setLatestOrder(order);
        setCart({});
        setDeliveryMethod('pickup');
        setDeliveryForm({ recipientName: '', phone: '', address: '', building: '', instructions: '' });
        void queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey({ userId }) });
        void queryClient.invalidateQueries({ queryKey: getGetQueueSummaryQueryKey() });
      },
    });
  };
  const toggleFavorite = (item: MenuItem) => {
    if (!userId) return;
    if (favoriteIds.has(item.id)) {
      removeFavorite.mutate({ menuItemId: item.id, params: { userId } }, { onSuccess: () => void queryClient.invalidateQueries({ queryKey: getGetFavoritesQueryKey({ userId }) }) });
    } else {
      addFavorite.mutate({ data: { userId, menuItemId: item.id } }, { onSuccess: () => void queryClient.invalidateQueries({ queryKey: getGetFavoritesQueryKey({ userId }) }) });
    }
  };
  const lastRefresh = Math.max(menuQuery.dataUpdatedAt ?? 0, queueQuery.dataUpdatedAt ?? 0, ordersQuery.dataUpdatedAt ?? 0) || undefined;
  if (!user) return <LoginPage />;
  return (
    <PageFrame eyebrow="Canteen / order ahead" title={`Good to see you, ${user.name.split(' ')[0]}.`} description="Browse what is cooking, choose pickup or door delivery, and get a clear signal when your order is ready." actions={<RefreshControls onRefresh={refresh} isFetching={menuQuery.isFetching || queueQuery.isFetching || ordersQuery.isFetching} updatedAt={lastRefresh} />}>
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="min-w-0">
          <section className="fade-up-delay-1 fade-up mb-6 rounded-3xl bg-foreground p-5 text-background sm:p-7">
            <div className="flex flex-wrap items-end justify-between gap-5">
              <div>
                <p className="font-mono-app text-[10px] uppercase tracking-[.2em] text-[hsl(var(--secondary))]">Today at the canteen</p>
                <h2 className="mt-2 max-w-xl font-display text-3xl leading-tight sm:text-4xl">Good food. <span className="text-primary">Better timing.</span></h2>
              </div>
              <div className="grid grid-cols-3 gap-5 text-left sm:gap-8">
                <div><p className="font-mono-app text-[10px] uppercase text-background/55">In queue</p><p data-testid="text-queue-active" className="mt-1 text-2xl font-extrabold">{queueQuery.data?.activeOrders ?? '—'}</p></div>
                <div><p className="font-mono-app text-[10px] uppercase text-background/55">Cooking</p><p data-testid="text-queue-preparing" className="mt-1 text-2xl font-extrabold">{queueQuery.data?.preparing ?? '—'}</p></div>
                <div><p className="font-mono-app text-[10px] uppercase text-background/55">Avg wait</p><p data-testid="text-queue-wait" className="mt-1 text-2xl font-extrabold">{queueQuery.data ? `${queueQuery.data.estimatedMinutes}m` : '—'}</p></div>
              </div>
            </div>
            {!user && <Link href="/login" data-testid="link-home-login" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5">Sign in to order <ArrowRight className="h-4 w-4" /></Link>}
          </section>
           {currentOrder && (
            <section className="fade-up-delay-2 fade-up mb-6 rounded-3xl border border-[hsl(var(--primary)/.3)] bg-card p-5 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-primary">Your live order</p><h2 data-testid="text-current-order-number" className="mt-1 font-display text-2xl">#{currentOrder.orderNumber}</h2></div>
                <StatusBadge status={currentOrder.status} />
              </div>
                <div className="mt-4 flex flex-wrap gap-3">
                  <span className="rounded-xl bg-muted px-3 py-2 text-sm"><strong className="font-mono-app text-primary">#{currentOrder.queuePosition}</strong> in the {currentOrder.deliveryMethod === 'door_delivery' ? 'delivery' : 'pickup'} queue</span>
                  <FulfillmentBadge order={currentOrder} />
                  <span className="max-w-full break-words rounded-xl bg-muted px-3 py-2 text-sm text-muted-foreground">{currentOrder.items.map((item) => `${item.quantity} × ${item.name}`).join(', ')}</span>
                  <span className="rounded-xl bg-muted px-3 py-2 text-sm font-mono-app font-bold text-primary">{currentOrder.currencySymbol}{currentOrder.total.toFixed(2)}</span>
              </div>
               <OrderDetails order={currentOrder} />
              <OrderProgress order={currentOrder} />
            </section>
          )}
          <section className="fade-up-delay-2 fade-up">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">The counter</p><h2 className="font-display text-2xl">What are you having?</h2></div>
              <div className="relative w-full sm:w-56"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={search} onChange={(event) => setSearch(event.target.value)} data-testid="input-menu-search" placeholder="Search the menu" className="h-10 w-full rounded-xl border border-border bg-card pl-9 pr-3 text-sm outline-none transition-colors focus:border-primary" /></div>
            </div>
            <div className="mb-5 flex gap-2 overflow-x-auto pb-1">
              {menuCategories.map((item) => <button type="button" key={item} onClick={() => setCategory(item)} data-testid={`button-category-${item.toLowerCase()}`} className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold transition-colors ${category === item ? 'bg-foreground text-background' : 'border border-border bg-card text-muted-foreground hover:bg-muted'}`}>{item}</button>)}
            </div>
            {menuQuery.isLoading || menuQuery.isFetching ? <LoadingRows count={4} /> : menuQuery.isError ? <ErrorNotice message="The menu board is taking a moment to respond." /> : !filteredMenu.length ? <EmptyState title="Nothing on this shelf" description="Try another category or search term. Available items will appear here." /> : (
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {filteredMenu.map((item) => (
                  <article key={item.id} data-testid={`card-menu-item-${item.id}`} className="card-lift rounded-3xl border border-border bg-card p-3">
                    <MenuVisual item={item} />
                    <div className="px-1 pb-1 pt-4"><div className="flex items-start justify-between gap-3"><h3 data-testid={`text-menu-name-${item.id}`} className="font-display text-xl leading-tight">{item.name}</h3><div className="flex items-center gap-2"><span data-testid={`text-menu-price-${item.id}`} className="shrink-0 font-mono-app text-sm font-bold text-primary">{item.currencySymbol}{item.price.toFixed(2)}</span>{user && <button type="button" aria-label={`favorite ${item.name}`} onClick={() => toggleFavorite(item)} className={`rounded-lg p-1.5 ${favoriteIds.has(item.id) ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`}><Heart className={`h-4 w-4 ${favoriteIds.has(item.id) ? 'fill-current' : ''}`} /></button>}</div></div><p className="mt-2 min-h-10 text-xs leading-5 text-muted-foreground">{item.description}</p><button type="button" onClick={() => addToCart(item)} disabled={!user} data-testid={`button-add-menu-${item.id}`} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-muted py-2.5 text-sm font-bold transition-colors hover:bg-primary hover:text-primary-foreground disabled:cursor-not-allowed disabled:opacity-45"><Plus className="h-4 w-4" /> {user ? 'Add to order' : 'Sign in to order'}</button></div>
                  </article>
                ))}
              </div>
            )}
          </section>
        </div>
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-6">
            <div className="flex items-center justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">Your tray</p><h2 className="font-display text-2xl">Ready when you are</h2></div><span data-testid="text-cart-count" className="flex h-8 min-w-8 items-center justify-center rounded-full bg-[hsl(var(--secondary))] px-2 font-mono-app text-xs font-bold">{cartItems.reduce((sum, entry) => sum + entry.quantity, 0)}</span></div>
             {!cartItems.length ? <div className="mt-5 rounded-2xl bg-muted/70 p-6 text-center"><ShoppingBag className="mx-auto h-6 w-6 text-muted-foreground" /><p className="mt-3 text-sm font-bold">Your tray is empty</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Tap “Add to order” on anything that looks good.</p></div> : <div className="mt-5 space-y-4">{cartItems.map(({ item, quantity }) => <div key={item.id} className="flex items-center justify-between gap-3"><div className="min-w-0"><p className="truncate text-sm font-bold">{item.name}</p><p className="font-mono-app text-xs text-muted-foreground">{item.currencySymbol}{(item.price * quantity).toFixed(2)}</p></div><div className="flex items-center gap-2 rounded-xl bg-muted p-1"><button type="button" onClick={() => adjustCart(item.id, -1)} data-testid={`button-decrease-cart-${item.id}`} className="flex h-6 w-6 items-center justify-center rounded-lg hover:bg-card"><Minus className="h-3 w-3" /></button><span className="w-4 text-center font-mono-app text-xs">{quantity}</span><button type="button" onClick={() => adjustCart(item.id, 1)} data-testid={`button-increase-cart-${item.id}`} className="flex h-6 w-6 items-center justify-center rounded-lg hover:bg-card"><Plus className="h-3 w-3" /></button></div></div>)}</div>}
              <div className="mt-6 border-t border-border pt-4">
                <div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span data-testid="text-cart-total" className="font-mono-app font-bold">{user?.currencySymbol ?? '₹'}{cartTotal.toFixed(2)}</span></div>
                <fieldset className="mt-4">
                  <legend className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">How should we get it to you?</legend>
                  <div className="grid grid-cols-2 gap-2">
                    {([
                      { value: 'pickup', label: 'Pickup', note: 'Collect at the counter' },
                      { value: 'door_delivery', label: 'Door delivery', note: 'Bring it to your campus location' },
                    ] as const).map((option) => (
                      <button type="button" key={option.value} onClick={() => setDeliveryMethod(option.value)} data-testid={`button-delivery-${option.value}`} aria-pressed={deliveryMethod === option.value} className={`rounded-xl border p-3 text-left transition-colors ${deliveryMethod === option.value ? 'border-primary bg-[hsl(var(--primary)/.1)] text-primary' : 'border-border text-muted-foreground hover:bg-muted'}`}>
                        <span className="flex items-center gap-2 text-xs font-bold">{option.value === 'door_delivery' ? <DoorOpen className="h-4 w-4" /> : <PackageCheck className="h-4 w-4" />}{option.label}</span>
                        <span className="mt-1 block text-[10px] leading-4 opacity-75">{option.note}</span>
                      </button>
                    ))}
                  </div>
                </fieldset>
                {deliveryMethod === 'door_delivery' && (
                  <div className="mt-3 grid gap-3 rounded-2xl bg-muted/60 p-3 sm:grid-cols-2">
                    <label className="block"><span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Recipient name</span><input value={deliveryForm.recipientName} onChange={(event) => setDeliveryForm((current) => ({ ...current, recipientName: event.target.value }))} placeholder={user.name} maxLength={120} autoComplete="name" data-testid="input-delivery-recipient" className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" /></label>
                    <label className="block"><span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Phone number</span><input required value={deliveryForm.phone} onChange={(event) => setDeliveryForm((current) => ({ ...current, phone: event.target.value }))} placeholder="+91 98765 43210" maxLength={20} autoComplete="tel" inputMode="tel" data-testid="input-delivery-phone" className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" /></label>
                    <label className="block sm:col-span-2"><span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Delivery address</span><input required value={deliveryForm.address} onChange={(event) => setDeliveryForm((current) => ({ ...current, address: event.target.value }))} placeholder="Hostel or campus location" maxLength={300} autoComplete="street-address" data-testid="input-delivery-address" className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" /></label>
                    <label className="block"><span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Room / block <span className="font-normal normal-case">(optional)</span></span><input value={deliveryForm.building} onChange={(event) => setDeliveryForm((current) => ({ ...current, building: event.target.value }))} placeholder="Block C, room 204" maxLength={120} data-testid="input-delivery-building" className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" /></label>
                    <label className="block"><span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Instructions <span className="font-normal normal-case">(optional)</span></span><input value={deliveryForm.instructions} onChange={(event) => setDeliveryForm((current) => ({ ...current, instructions: event.target.value }))} placeholder="Call on arrival" maxLength={250} data-testid="input-delivery-instructions" className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" /></label>
                    {!deliveryIsValid && <p className="text-xs text-[hsl(var(--destructive))] sm:col-span-2">Add a valid phone number and a delivery address before placing this order.</p>}
                  </div>
                )}
                <label className="mt-4 block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Payment at checkout</span><select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value as PaymentMethod)} className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm"><option value="upi">UPI — instant campus payment</option><option value="card">Card</option><option value="cash">Pay at counter</option></select></label>
                {paymentMethod === 'upi' && <p className="mt-2 rounded-xl bg-[hsl(var(--accent)/.08)] p-2.5 text-xs text-muted-foreground">UPI checkout is ready for this MVP; you will confirm the payment in the next step.</p>}
                <button type="button" onClick={placeOrder} disabled={!userId || !cartItems.length || !deliveryIsValid || createOrder.isPending} data-testid="button-place-order" className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45">{createOrder.isPending ? 'Sending to kitchen…' : `Place order · ${paymentMethod.toUpperCase()}`} <ArrowRight className="h-4 w-4" /></button>
                {createOrder.isError && <p className="mt-2 text-xs text-[hsl(var(--destructive))]">Could not place that order. Please try again.</p>}
              </div>
          </div>
          <div className="mt-4 rounded-2xl border border-border bg-[hsl(var(--accent)/.08)] p-4"><div className="flex gap-3"><Clock3 className="mt-0.5 h-4 w-4 shrink-0 text-accent" /><div><p className="text-sm font-bold">Pickup rhythm</p><p className="mt-1 text-xs leading-5 text-muted-foreground">We will move your order through the queue and keep the estimate honest.</p></div></div></div>
        </aside>
       </div>
       <CampusExtras user={user} orders={ordersQuery.data ?? []} />
    </PageFrame>
  );
}

function LoginPage() {
  const [, setLocation] = useLocation();
  const { saveUser } = useCurrentUser();
  const login = useLogin();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'student' as Role, country: 'India', college: '', campusEmail: '', studentId: '' });
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    login.mutate({ data: form }, { onSuccess: (user) => { saveUser(user); setLocation(user.role === 'staff' ? '/staff' : '/'); } });
  };
  return (
    <div className="surface-grid flex min-h-[calc(100dvh-72px)] items-center px-4 pb-28 pt-10 sm:px-6 md:pb-10">
      <div className="mx-auto grid w-full max-w-5xl overflow-hidden rounded-[2rem] border border-border bg-card shadow-md md:grid-cols-[.9fr_1.1fr]">
        <div className="relative overflow-hidden bg-foreground p-7 text-background sm:p-10"><div className="absolute -right-16 -top-20 h-56 w-56 rounded-full border-[28px] border-[hsl(var(--primary)/.35)]" /><div className="absolute -bottom-24 -left-14 h-56 w-56 rounded-full bg-[hsl(var(--secondary)/.25)]" /><div className="relative"><LogoMark /><p className="mt-14 font-mono-app text-[10px] uppercase tracking-[.22em] text-[hsl(var(--secondary))]">One less queue</p><h1 className="mt-3 max-w-sm font-display text-4xl leading-[1.02] sm:text-5xl">Campus food, made simple.</h1><p className="mt-5 max-w-sm text-sm leading-6 text-background/65">Campus bites helps you discover your campus menu, order ahead, and collect when your food is ready.</p><div className="mt-12 flex items-center gap-2 font-mono-app text-[10px] uppercase tracking-wider text-background/50"><span className="h-2 w-2 rounded-full bg-[hsl(var(--secondary))]" /> live canteen companion</div></div></div>
         <form onSubmit={submit} className="p-6 sm:p-10"><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.2em] text-primary">Welcome in</p><h2 className="mt-2 font-display text-3xl">Enter Campus bites</h2><p className="mt-2 text-sm text-muted-foreground">Your college and student ID tailor the menu and currency.</p><div className="mt-7 grid gap-4 sm:grid-cols-2"><label className="block sm:col-span-2"><span className="mb-1.5 block text-xs font-bold">Full name</span><input required autoComplete="name" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} data-testid="input-login-name" className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" placeholder="e.g. Samira Khan" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold">Account email</span><input required type="email" autoComplete="username" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} data-testid="input-login-email" className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" placeholder="you@example.com" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold">Password</span><input required type="password" autoComplete="current-password" value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} data-testid="input-login-password" className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" placeholder="••••••••" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold">Country</span><select required value={form.country} onChange={(event) => setForm({ ...form, country: event.target.value })} className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary"><option>India</option><option>United States</option><option>United Kingdom</option><option>Canada</option><option>Australia</option><option>United Arab Emirates</option></select></label><label className="block"><span className="mb-1.5 block text-xs font-bold">College / university</span><input required value={form.college} onChange={(event) => setForm({ ...form, college: event.target.value })} className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" placeholder="Your campus" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold">Campus email</span><input required type="email" autoComplete="email" value={form.campusEmail} onChange={(event) => setForm({ ...form, campusEmail: event.target.value })} className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" placeholder="you@college.edu" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold">Student ID / staff ID</span><input required value={form.studentId} onChange={(event) => setForm({ ...form, studentId: event.target.value })} className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary" placeholder="ID-2026-001" /></label><div className="sm:col-span-2"><span className="mb-1.5 block text-xs font-bold">I am signing in as</span><div className="grid grid-cols-2 gap-2">{(['student', 'staff'] as Role[]).map((role) => <button type="button" key={role} onClick={() => setForm({ ...form, role })} data-testid={`button-role-${role}`} className={`rounded-xl border px-3 py-3 text-left text-sm font-bold transition-colors ${form.role === role ? 'border-primary bg-[hsl(var(--primary)/.1)] text-primary' : 'border-border text-muted-foreground hover:bg-muted'}`}><span className="block capitalize">{role}</span><span className="mt-1 block text-[10px] font-normal opacity-70">{role === 'student' ? 'Order ahead' : 'Run the counter'}</span></button>)}</div></div></div>{login.isError && <p data-testid="status-login-error" className="mt-4 rounded-xl bg-[hsl(var(--destructive)/.08)] p-3 text-xs text-[hsl(var(--destructive))]">We could not sign you in. Check your details and try once more.</p>}<button type="submit" disabled={login.isPending} data-testid="button-submit-login" className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:opacity-50">{login.isPending ? 'Entering…' : 'Continue to Campus bites'} <ArrowRight className="h-4 w-4" /></button></form>
      </div>
    </div>
  );
}

function OrderRow({ order, onStatus }: { order: Order; onStatus: (order: Order, status: 'placed' | 'preparing' | 'ready') => void }) {
  const nextStatus = order.status === 'placed' ? 'preparing' : order.status === 'preparing' ? 'ready' : null;
  return (
    <div data-testid={`row-order-${order.id}`} className="grid gap-4 border-b border-border px-4 py-4 last:border-b-0 sm:px-5 lg:grid-cols-[minmax(0,1.6fr)_120px_130px_auto] lg:items-center">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2"><span className="font-mono-app text-sm font-bold text-primary">#{order.orderNumber}</span><StatusBadge status={order.status} /><FulfillmentBadge order={order} /></div>
        <p className="mt-1 text-sm font-bold">{order.userName}</p>
        <p className="mt-1 break-words text-xs text-muted-foreground">{order.items.map((item) => `${item.quantity} × ${item.name}`).join(' · ')}</p>
        <p className="mt-2 break-words text-xs text-muted-foreground">{order.deliveryMethod === 'door_delivery' ? `${order.deliveryRecipientName} · ${order.deliveryPhone} · ${order.deliveryAddress}${order.deliveryBuilding ? ` · ${order.deliveryBuilding}` : ''}` : 'Collect from the campus canteen counter'}</p>
        {order.deliveryMethod === 'door_delivery' && order.deliveryInstructions && <p className="mt-1 break-words text-[11px] text-muted-foreground">Note: {order.deliveryInstructions}</p>}
      </div>
      <div><p className="font-mono-app text-xs text-muted-foreground">Queue position</p><p className="mt-1 text-sm font-bold">{order.queuePosition > 0 ? `#${order.queuePosition}` : 'At counter'}</p></div>
      <div><p className="font-mono-app text-xs text-muted-foreground">Order total</p><p data-testid={`text-order-total-${order.id}`} className="mt-1 font-mono-app text-sm font-bold">{order.currencySymbol}{order.total.toFixed(2)}</p><p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{order.paymentMethod}</p></div>
      <div className="flex items-center gap-2 lg:justify-end">{nextStatus ? <button type="button" onClick={() => onStatus(order, nextStatus)} data-testid={`button-advance-order-${order.id}`} className="inline-flex items-center gap-2 rounded-xl bg-foreground px-3 py-2 text-xs font-bold text-background hover:bg-primary">{nextStatus === 'preparing' ? 'Start preparing' : order.deliveryMethod === 'door_delivery' ? 'Hand to delivery' : 'Mark ready'} <ArrowRight className="h-3.5 w-3.5" /></button> : <span className="inline-flex items-center gap-1 rounded-xl bg-[hsl(var(--accent)/.1)] px-3 py-2 text-xs font-bold text-accent"><Check className="h-3.5 w-3.5" /> Complete</span>}</div>
    </div>
  );
}

function StaffMenuBoard() {
  const menuQuery = useGetMenu({ country: 'India', college: 'all' });
  const updateMenuItem = useUpdateMenuItem();
  const toggleAvailability = (item: MenuItem) => {
    updateMenuItem.mutate({
      menuItemId: item.id,
      data: {
        name: item.name,
        description: item.description,
        price: item.price,
        category: item.category,
        image: item.image,
        available: !item.available,
        country: item.country,
        college: item.college,
      },
    }, { onSuccess: () => void menuQuery.refetch() });
  };
  return <section className="mt-5 overflow-hidden rounded-3xl border border-border bg-card">
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-5 sm:p-6"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">Menu management</p><h2 className="mt-1 font-display text-2xl">Keep the board current</h2></div><span className="rounded-full bg-muted px-3 py-1 text-xs font-bold">{menuQuery.data?.length ?? 0} items</span></div>
    {menuQuery.isLoading ? <div className="p-5"><LoadingRows count={3} /></div> : <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">{(menuQuery.data ?? []).map((item) => <div key={item.id} className="rounded-2xl border border-border p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-bold">{item.name}</p><p className="mt-1 text-xs text-muted-foreground">{item.category} · {item.currencySymbol}{item.price.toFixed(2)}</p></div><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${item.available ? 'bg-[hsl(var(--accent)/.12)] text-accent' : 'bg-muted text-muted-foreground'}`}>{item.available ? 'Available' : 'Sold out'}</span></div><button type="button" onClick={() => toggleAvailability(item)} disabled={updateMenuItem.isPending} className="mt-4 w-full rounded-xl border border-border py-2 text-xs font-bold hover:bg-muted disabled:opacity-50">{item.available ? 'Mark sold out' : 'Put back on menu'}</button></div>)}</div>}
  </section>;
}

function downloadCsv(orders: Order[]) {
  const rows = [['Order', 'Customer', 'Status', 'Fulfillment', 'Payment', 'Queue position', 'Total', 'Currency', 'Delivery address', 'Created'], ...orders.map((order) => [order.orderNumber, order.userName, order.status, order.deliveryMethod, order.paymentMethod, String(order.queuePosition), order.total.toFixed(2), order.currency, order.deliveryMethod === 'door_delivery' ? `${order.deliveryAddress}${order.deliveryBuilding ? `, ${order.deliveryBuilding}` : ''}` : 'Campus canteen counter', order.createdAt])];
  const blob = new Blob([rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(',')).join('\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'queuebite-orders.csv';
  anchor.click();
  URL.revokeObjectURL(url);
}

function StaffPage() {
  const { user, saveUser } = useCurrentUser();
  const staffOrdersParams = { role: 'staff' as const };
  const ordersQuery = useGetOrders(staffOrdersParams, { query: { queryKey: getGetOrdersQueryKey(staffOrdersParams) } });
  const queueQuery = useGetQueueSummary();
  const updateStatus = useUpdateOrderStatus();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<'all' | 'placed' | 'preparing' | 'ready'>('all');
  const [, setLocation] = useLocation();
  useEffect(() => { if (user && user.role !== 'staff') setLocation('/'); }, [user, setLocation]);
  if (!user) return <LoginPage />;
  const orders = ordersQuery.data ?? [];
  const visibleOrders = filter === 'all' ? orders : orders.filter((order) => order.status === filter);
  const refresh = () => { void Promise.all([ordersQuery.refetch(), queueQuery.refetch()]); };
  const moveOrder = (order: Order, status: 'placed' | 'preparing' | 'ready') => updateStatus.mutate({ orderId: order.id, data: { status } }, { onSuccess: () => { void queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(staffOrdersParams) }); void queryClient.invalidateQueries({ queryKey: getGetQueueSummaryQueryKey() }); } });
  const max = Math.max(queueQuery.data?.activeOrders ?? 1, 1);
  return (
    <PageFrame eyebrow="Canteen / operations" title="Keep the counter moving." description="A focused view of every incoming order, what is cooking now, and what needs a pickup call." actions={<div className="flex items-center gap-2"><button type="button" onClick={() => downloadCsv(orders)} disabled={!orders.length} data-testid="button-export-orders" className="inline-flex h-9 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold text-muted-foreground hover:bg-muted disabled:opacity-40"><Download className="h-3.5 w-3.5" /> CSV</button><RefreshControls onRefresh={refresh} isFetching={ordersQuery.isFetching || queueQuery.isFetching} updatedAt={Math.max(ordersQuery.dataUpdatedAt ?? 0, queueQuery.dataUpdatedAt ?? 0)} /></div>}>
      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: 'Active orders', value: queueQuery.data?.activeOrders, tone: 'text-primary', icon: Users },
          { label: 'Preparing now', value: queueQuery.data?.preparing, tone: 'text-accent', icon: UtensilsCrossed },
          { label: 'Ready to collect', value: queueQuery.data?.ready, tone: 'text-[hsl(var(--secondary-foreground))]', icon: PackageCheck },
          { label: 'Estimated wait', value: queueQuery.data ? `${queueQuery.data.estimatedMinutes} min` : undefined, tone: 'text-primary', icon: Clock3 },
        ].map((metric, index) => { const Icon = metric.icon; return <div key={metric.label} data-testid={`card-kpi-${index}`} className="fade-up rounded-2xl border border-border bg-card p-5" style={{ animationDelay: `${index * 70}ms` }}><div className="flex items-center justify-between"><p className="text-xs font-bold text-muted-foreground">{metric.label}</p><Icon className={`h-4 w-4 ${metric.tone}`} /></div><p data-testid={`text-kpi-${index}`} className={`mt-3 font-mono-app text-3xl font-bold ${metric.tone}`}>{metric.value ?? '—'}</p></div>; })}
      </div>
      <div className="mb-5 grid gap-5 lg:grid-cols-[1fr_310px]">
        <section className="rounded-3xl border border-border bg-card p-5 sm:p-6"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">Queue pulse</p><h2 className="mt-1 font-display text-2xl">Today at a glance</h2></div><span className="rounded-full bg-[hsl(var(--accent)/.1)] px-2.5 py-1 font-mono-app text-[10px] font-bold text-accent">LIVE VIEW</span></div><div className="mt-7 space-y-5">{[{ label: 'Orders in queue', value: queueQuery.data?.activeOrders ?? 0, color: 'bg-primary' }, { label: 'Being prepared', value: queueQuery.data?.preparing ?? 0, color: 'bg-accent' }, { label: 'Ready for pickup', value: queueQuery.data?.ready ?? 0, color: 'bg-[hsl(var(--secondary-foreground))]' }].map((row) => <div key={row.label}><div className="mb-2 flex justify-between text-sm"><span className="font-semibold">{row.label}</span><span className="font-mono-app font-bold">{row.value}</span></div><div className="h-3 overflow-hidden rounded-full bg-muted"><div className={`h-full rounded-full ${row.color} transition-all`} style={{ width: `${Math.max((row.value / max) * 100, row.value ? 8 : 0)}%` }} /></div></div>)}</div></section>
        <section className="rounded-3xl bg-foreground p-5 text-background sm:p-6"><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-[hsl(var(--secondary))]">Counter note</p><h2 className="mt-3 font-display text-2xl">Fast hands, clear calls.</h2><p className="mt-3 text-sm leading-6 text-background/65">Move an order only when the kitchen has actually moved it. Students see the same status instantly.</p><div className="mt-6 flex items-center gap-2 text-xs text-background/70"><span className="h-2 w-2 rounded-full bg-[hsl(var(--secondary))]" /> Updates sync after every action</div></section>
      </div>
      <section className="overflow-hidden rounded-3xl border border-border bg-card"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-border p-5 sm:p-6"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">Incoming orders</p><h2 className="mt-1 font-display text-2xl">The service board</h2></div><div className="flex gap-1 overflow-x-auto rounded-xl bg-muted p-1">{(['all', 'placed', 'preparing', 'ready'] as const).map((item) => <button type="button" key={item} onClick={() => setFilter(item)} data-testid={`button-filter-${item}`} className={`shrink-0 rounded-lg px-3 py-1.5 text-xs font-bold capitalize ${filter === item ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}>{item === 'all' ? 'All orders' : statusLabels[item]}</button>)}</div></div>{ordersQuery.isLoading || ordersQuery.isFetching ? <div className="p-5"><LoadingRows count={4} /></div> : ordersQuery.isError ? <div className="p-5"><ErrorNotice message="The service board could not load." /></div> : !visibleOrders.length ? <div className="p-5"><EmptyState title="No orders in this lane" description="When students place an order, it will appear here with a clear next action." icon={PackageCheck} /></div> : <div>{visibleOrders.map((order) => <OrderRow key={order.id} order={order} onStatus={moveOrder} />)}</div>}</section>
      {updateStatus.isError && <p className="mt-3 text-sm text-[hsl(var(--destructive))]">That status update did not save. Refresh and try again.</p>}
      <StaffMenuBoard />
    </PageFrame>
  );
}

type ChatMessage = { role: 'assistant' | 'user'; text: string };

function AssistantPage() {
  const { user } = useCurrentUser();
  const askAssistant = useAskAssistant();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'assistant', text: 'Hi, I can help with today’s menu, your order status, and the pickup queue. What do you need to know?' }]);
  const suggestions = ['What is popular today?', 'Where is my order?', 'How long is the queue?'];
  const send = (message = input) => {
    const trimmed = message.trim();
    if (!trimmed || askAssistant.isPending) return;
    setInput('');
    setMessages((current) => [...current, { role: 'user', text: trimmed }]);
    askAssistant.mutate({ data: { message: trimmed, userId: user?.id } }, { onSuccess: (response) => setMessages((current) => [...current, { role: 'assistant', text: response.answer }]) });
  };
  return (
    <PageFrame eyebrow="Canteen / assistant" title="Ask the counter." description="A small, focused helper for menu questions, order status, and the queue. No wandering off-topic." actions={<div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-bold text-muted-foreground"><Sparkles className="h-4 w-4 text-primary" /> Canteen only</div>}>
      <div className="mx-auto grid max-w-5xl gap-5 lg:grid-cols-[.72fr_1.28fr]">
        <aside className="rounded-3xl bg-foreground p-6 text-background sm:p-8"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Bot className="h-6 w-6" /></div><h2 className="mt-7 font-display text-3xl leading-tight">Small questions deserve quick answers.</h2><p className="mt-4 text-sm leading-6 text-background/65">Ask about an item, check where your order is, or get a read on the queue before you leave class.</p><div className="mt-8 space-y-3">{['Menu and availability', 'Order status', 'Pickup timing'].map((item) => <div key={item} className="flex items-center gap-3 text-sm font-semibold"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[hsl(var(--secondary)/.2)] text-[hsl(var(--secondary))]"><Check className="h-3.5 w-3.5" /></span>{item}</div>)}</div></aside>
        <section className="flex min-h-[560px] flex-col rounded-3xl border border-border bg-card p-4 sm:p-6"><div className="flex items-center justify-between border-b border-border pb-4"><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[hsl(var(--primary)/.12)] text-primary"><Bot className="h-4 w-4" /></span><div><h2 className="text-sm font-bold">QueueBite assistant</h2><p className="font-mono-app text-[10px] text-muted-foreground">usually replies in a moment</p></div></div><span className="flex items-center gap-1.5 font-mono-app text-[10px] text-accent"><span className="h-1.5 w-1.5 rounded-full bg-accent" /> available</span></div><div className="flex-1 space-y-4 overflow-y-auto py-5">{messages.map((message, index) => <div key={`${message.role}-${index}`} data-testid={`chat-message-${index}`} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-6 ${message.role === 'user' ? 'rounded-br-md bg-foreground text-background' : 'rounded-bl-md bg-muted text-foreground'}`}>{message.text}</div></div>)}{askAssistant.isPending && <div className="flex justify-start"><div className="rounded-2xl rounded-bl-md bg-muted px-4 py-3"><span className="inline-flex gap-1"><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground" /><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:120ms]" /><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:240ms]" /></span></div></div>}{askAssistant.isError && <p className="text-xs text-[hsl(var(--destructive))]">The assistant could not answer just now. Try again.</p>}</div><div className="mb-3 flex gap-2 overflow-x-auto pb-1">{suggestions.map((suggestion) => <button type="button" key={suggestion} onClick={() => send(suggestion)} data-testid={`button-suggestion-${suggestion.slice(0, 8).replaceAll(' ', '-').toLowerCase()}`} className="shrink-0 rounded-full border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-muted hover:text-foreground">{suggestion}</button>)}</div><form onSubmit={(event) => { event.preventDefault(); send(); }} className="flex items-center gap-2 rounded-2xl border border-border bg-background p-2"><input value={input} onChange={(event) => setInput(event.target.value)} data-testid="input-assistant-message" className="min-w-0 flex-1 bg-transparent px-2 text-sm outline-none" placeholder="Ask about the canteen…" /><button type="submit" disabled={!input.trim() || askAssistant.isPending} data-testid="button-send-assistant" className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-40"><Send className="h-4 w-4" /></button></form></section>
      </div>
    </PageFrame>
  );
}

function Router() {
  const { user, saveUser } = useCurrentUser();
  const logout = useLogout();
  const doLogout = () => logout.mutate(undefined, { onSuccess: () => saveUser(null) });
  return <Shell user={user} onLogout={doLogout}><ErrorBoundary resetKey={window.location.pathname}><Switch><Route path="/" component={Home} /><Route path="/login" component={LoginPage} /><Route path="/staff" component={StaffPage} /><Route path="/assistant" component={AssistantPage} /><Route component={NotFound} /></Switch></ErrorBoundary></Shell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></QueryClientProvider>;
}

export default App;